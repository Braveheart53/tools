# Atomic Theory Atlas — authoring patterns (MUST follow exactly)

You are writing a **body fragment** only: no `<html>`, `<head>`, `<header>`, `<nav>`, `<footer>`, no `<script>`, no `<style>`.
The build script wraps your fragment in the shared shell. Output raw HTML.

## Page skeleton

```html
<section class="hero">
  <div class="container">
    <div class="eyebrow">SHORT KICKER</div>
    <h1>Page title</h1>
    <p class="lead">One or two sentences of orientation.</p>
    <p class="small muted">Every equation is tagged <span class="pill stated">Stated</span> or <span class="pill derived">Derived here</span>. Numerical values use CODATA 2022<a class="cite" href="references.html#r14">[14]</a>.</p>
  </div>
</section>

<section id="section-slug">
  <div class="container">
    <h2>1. Section heading</h2>
    <p>Prose. Cite like this<a class="cite" href="references.html#r13">[13]</a>.</p>
    ... equation blocks ...
  </div>
</section>
```

Available wrappers: `.container` (default reading width), `.container-wide` (wide, for timelines/tables).
Other utility classes that exist in style.css: `.lead`, `.small`, `.muted`, `.mono`, `.eyebrow`, `.card`,
`.grid-2`, `.two-col`, `.toc`, `.callout`, `.callout.info-box`, `.table-wrap`, `.orb-grid`, `.orb`,
`.orb-label`, `.orb-sub`, `.levels`, `.person-card`, `.person-avatar`, `.person-links`.
**Do not invent new class names** — unstyled classes will look broken.

## Equation block — the exact required pattern

Every single equation MUST use this structure. `aria-controls` id must be unique across the page
and must match the `.vars` `id`.

```html
<div class="eq" id="eq-UNIQUESLUG">
  <div class="eq-head">
    <h3 class="eq-title">Human-readable name of the equation</h3>
    <div class="eq-tools"><span class="pill stated">Stated</span>
      <button class="info" aria-controls="v-UNIQUESLUG" aria-expanded="false">&#9432;&nbsp;<span class="info-label">Define variables</span></button></div>
  </div>
  <div class="eq-body">\[ E = h\nu \]</div>
  <p class="eq-note">One or two sentences: what it means, when it applies, and a citation<a class="cite" href="references.html#r5">[5]</a>.</p>
  <div class="vars" id="v-UNIQUESLUG" hidden><div class="table-wrap"><table>
    <thead><tr><th>Symbol</th><th>Meaning</th><th>SI unit</th></tr></thead>
    <tbody>
    <tr><td>\(E\)</td><td>Photon energy</td><td>J</td></tr>
    <tr><td>\(h\)</td><td>Planck constant, \(6.626\,070\,15\times10^{-34}\) (exact)</td><td>J&middot;s</td></tr>
    <tr><td>\(\nu\)</td><td>Transition frequency</td><td>Hz</td></tr>
    </tbody></table></div></div>
</div>
```

### Pill tag rules
- `<span class="pill stated">Stated</span>` — quoted from a cited standard reference. Nothing was
  algebraically manipulated here.
- `<span class="pill derived">Derived here</span>` — algebra or a numerical evaluation performed on
  this site. **A derived block MUST be followed by an explicit step list:**

```html
  <div class="deriv"><ol>
    <li>Start from \( ... \) as stated above.</li>
    <li>Substitute \( ... \).</li>
    <li>Evaluate numerically: \( ... = 1.234\,56\times10^{-19}\ \mathrm{J} \).</li>
  </ol></div>
```
  Place `.deriv` after `.eq-note` and before `.vars`.
- `<span class="pill data">Measured value</span>` — a tabulated experimental/defined number.

## Math
- Display math: `\[ ... \]`. Inline math: `\( ... \)`. **Never** use `$` or `$$`.
- KaTeX renders offline. Do not use LaTeX packages/environments beyond KaTeX support
  (`aligned`, `cases`, `array`, `matrix`, `underbrace`, `text`, `mathrm`, `tfrac`, `dfrac` are fine).
  **Never** use `align` (use `aligned` inside `\[ \]`), `\label`, `\ref`, `\begin{equation}`.
- Thin-space digit grouping: `9\,192\,631\,770`.
- Units in math: `\ \mathrm{Hz}`, `\ \mathrm{J}`, `\ \mathrm{m^{-1}}`.

## Citations
- In body prose: `<a class="cite" href="references.html#rNN">[NN]</a>` immediately before the period.
- Only use reference numbers from the list in `REFERENCES.md`. If you need a source not in that
  list, do **not** invent a number — instead append a line to `/home/user/workspace/atomic-atlas/NEWREFS-<yourpage>.txt`
  in the form `TITLE | URL` and use a placeholder `<a class="cite" href="references.html#rNEW1">[NEW1]</a>`,
  numbering NEW1, NEW2, ... within your page only.

## Tables
Always wrap: `<div class="table-wrap"><table><caption>…</caption><thead>…</thead><tbody>…</tbody></table></div>`
Captions are required and should be a full explanatory sentence.

## SVG diagrams
Hand-written inline SVG only. Use `currentColor` for strokes/text where possible, and the CSS
variables `var(--color-primary)`, `var(--color-blue)`, `var(--color-violet)`, `var(--color-orange)`,
`var(--color-text)`, `var(--color-text-muted)`, `var(--color-border)` for fills so dark mode works.
Give every SVG `role="img"` and an `<title>`. Use class `levels` on level-scheme SVGs and set
`viewBox` with `preserveAspectRatio="xMidYMid meet"`.

## Writing quality bar
- Technical audience: an RF/microwave engineer and radio astronomer. Use correct terminology, do not
  over-explain basics, and draw RF/cavity/waveguide analogies where they are genuinely correct.
- No em-dash overuse, no exclamation marks, no emoji, no "delve", no marketing tone.
- Every numeric claim needs a citation or a shown derivation.
- Keep paragraphs to 2–5 sentences.

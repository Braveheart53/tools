# Reference numbers available for citation (use `references.html#rNN`)

1 Dalton / Britannica "Atom"
2 Rutherford 1911 / Britannica "Atom"
3 Bohr 1913 / Nobel Prize facts
4 Max Planck (Wikipedia)
5 Planck Nobel Prize 1918 facts
6 Einstein Nobel Prize 1921 facts
7 Heisenberg Nobel 1932 biographical
8 Oliver Heaviside (Britannica)
9 Heaviside, Physics Today feature
10 J. Robert Oppenheimer (Wikipedia)
11 Oppenheimer, AHF Nuclear Museum profile
12 Feynman Nobel Prize 1965 facts
13 NIST hydrogen energy levels incl. Lamb shift (Physical Reference Data)
14 NIST CODATA recommended values of the fundamental physical constants
15 NIST Atomic Spectra Database (ASD)
16 BIPM SI Brochure
17 BIPM definition of the second
18 NIST SI Units – Time
19 Caesium standard (Wikipedia)
20 Atomic clock (Wikipedia)
21 Charles H. Townes (Wikipedia)
22 Townes, Proc. Bayl. Univ. Med. Cent. PMC3257993
23 Optica, Charles Hard Townes biography
24 Harvard Physics, invention of the hydrogen maser (PDF)
25 Major et al., early atomic clock history, Metrologia (PDF)
26 C. Morningstar, "Update on Glueballs," arXiv:2502.02547
27 Y. Huang et al., X(2370) at BESIII, arXiv:2503.13286
28 Phys.org, BESIII glueball evidence, May 2024
29 Xinhua, Chinese researchers confirm glueball, Aug 2026
30 Glueball (Wikipedia)
31 R. M. Martin, Electronic Structure (CUP/OUP)
32 LibreTexts, The Hartree-Fock Approximation
33 NIST CUU Units (electromagnetic quantities)
34 Ramsey, separated oscillating fields / Nobel 1989 facts
35 D. W. Allan, "Statistics of Atomic Frequency Standards," Proc. IEEE 54(2), 1966
36 Schwinger Nobel Prize 1965 facts
37 Nobel Prize in Physics 2004 (Gross, Politzer, Wilczek)
38 Kramers-Kronig relations (Wikipedia)
39 Gordon, Zeiger & Townes, Phys. Rev. 95, 282 (1954) — the first maser (NH3 J=K=3, 23 870 Mc/s)
40 CIPM recommended standard frequencies, 2021 update, arXiv:2401.14537
41 Stimulated emission / Einstein A and B coefficients (Wikipedia)
42 Pauli Nobel Prize 1945 facts
43 Erwin Schrodinger (Wikipedia)
44 Paul Dirac (Wikipedia)
45 Rabi Nobel Prize 1944 facts
46 Atomic structure / central-field treatment (LibreTexts Quantum Mechanics in Chemistry)
47 NIST CODATA Rydberg constant value page
48 Atomic orbital / spherical harmonics (Wikipedia)
49 Zeeman effect (Wikipedia)
50 Blackbody radiation shift and Stark shift in optical clocks
51 Hyperfine structure (Wikipedia)
52 Hydrogen line, 21 cm (Wikipedia)
53 Selection rules (Wikipedia)
54 Kastler Nobel Prize 1966 facts (optical pumping)
55 Water maser 6(16)-5(23) 22.235 08 GHz, ApJ 368, 215
56 Methanol maser rest frequencies, A&A (2004)
57 Astrophysical maser (Wikipedia)

## Verified numerical values you MUST use (do not recompute differently)

- Cs-133 ground-state hyperfine splitting: 9 192 631 770 Hz **exactly** (defines the SI second) [17]
- H I 21 cm line: 1 420 405 751.768(2) Hz; lambda = 21.106 114 054 cm; E = 9.411 708e-25 J
  = 5.874 326 microeV; A21 = 2.9e-15 s^-1; tau ~ 11 Myr; natural width 4.6e-16 Hz [52]
- First maser: NH3 inversion line J = K = 3 at 23 870 Mc/s (23.870 GHz) [39]
- CIPM 2021 recommended optical frequencies [40]:
  - Sr-87  1S0-3P0 = 429 228 004 229 872.99 Hz (698.446 nm)
  - Yb-171 1S0-3P0 = 518 295 836 590 863.63 Hz (578.420 nm)
  - Al+ -27 1S0-3P0 = 1 121 015 393 207 859.16 Hz (267.429 nm)
  - Sr+ -88 = 444 779 044 095 486.3 Hz
  - Hg+ -199 = 1 064 721 609 899 146.96 Hz
  - Yb+ -171 E3 octupole = 642 121 496 772 645.12 Hz
- Rb-87 ground-state hyperfine = 6 834 682 610.904 312 Hz (secondary representation) [40]
- H maser 1s hyperfine = 1 420 405 751.768 Hz [52]
- Astrophysical maser lines: H2O 6(16)-5(23) = 22.235 08 GHz [55];
  methanol 5(1)->6(0) A+ = 6668.5192(8) MHz and 2(0)->3(-1) E = 12 178.597(4) MHz [56];
  OH 1612, 1665.402, 1667.359, 1720 MHz [57]; SiO v=1 J=2-1 approx 43 GHz (state as approximate) [57]
- CODATA 2022 [14]: alpha = 7.297 352 5643e-3 (1/alpha = 137.035 999 177);
  mu_B = 9.274 010 0657e-24 J/T; mu_B/h = 13.996 244 917 11 GHz/T;
  R_inf = 10 973 731.568 157(12) m^-1; hcR_inf = 13.605 693 122 990 eV;
  E_h = 27.211 386 245 981 eV = 4.359 744 7222e-18 J;
  a_0 = 5.291 772 105 44e-11 m; m_e = 9.109 383 7139e-31 kg;
  eps_0 = 8.854 187 8188e-12 F/m; e = 1.602 176 634e-19 C (exact);
  h = 6.626 070 15e-34 J s (exact); hbar = 1.054 571 817e-34 J s (exact);
  c = 299 792 458 m/s (exact); k_B = 1.380 649e-23 J/K (exact)
- Recomputed on this site: E_1(H) = -2.179 872 4e-18 J = -13.605 693 eV; E_2 = -3.401 423 3 eV;
  Lyman-alpha 10.204 270 eV -> 2.467 381e15 Hz -> 121.502 nm;
  Balmer-alpha 656.11 nm (infinite nuclear mass) vs 656.47 nm using R_H = 1.096 775 8e7 m^-1;
  hydrogen n=2 fine structure 2p3/2 - 2p1/2 = alpha^4 m_e c^2 / 32 = 4.5283e-5 eV = 10.949 GHz
  (experimental 10 969 MHz [13]);
  Lamb shift 2s1/2 - 2p1/2 = 1057.845 MHz = 4.3749e-6 eV [13];
  free-electron Zeeman with g_J = 2 at 1 mT -> 27.992 MHz;
  21 cm h*nu/(k_B T) at 300 K = 2.2723e-4, so exp(-h nu / k T) = 0.999 772 8;
  Doppler FWHM of the 21 cm line in atomic hydrogen at 300 K = 17.55 kHz;
  electron plasma frequency for n_e = 1e18 m^-3 = 8.9787 GHz;
  Schwinger one-loop anomaly a_e = alpha/(2 pi) = 1.161 409 7e-3;
  <r>_1s = 1.5 a_0 = 7.9377e-11 m;
  Ramsey central-fringe FWHM = 1/(2T)

#!/usr/bin/env python3
"""Builds the Atomic Theory Atlas static site from body fragments + shared shell."""
import os, re, html, json
from refs_data import build_reference_table, build_reference_counts

SRC = os.path.dirname(os.path.abspath(__file__))
PARTS = os.path.join(SRC, "parts")

NAV = [
    ("index.html", "Overview"),
    ("timeline.html", "Timeline"),
    ("qed.html", "QED &amp; Relativistic"),
    ("orbitals.html", "Orbitals &amp; Levels"),
    ("masers.html", "Masers &amp; Clocks"),
    ("macro.html", "Macro Models"),
    ("glueballs.html", "Glueballs"),
    ("references.html", "References"),
]

LOGO = """<svg viewBox="0 0 64 64" fill="none" aria-hidden="true">
  <circle cx="32" cy="32" r="3.5" fill="currentColor"></circle>
  <ellipse cx="32" cy="32" rx="26" ry="10" stroke="currentColor" stroke-width="2.2"></ellipse>
  <ellipse cx="32" cy="32" rx="26" ry="10" stroke="currentColor" stroke-width="2.2" transform="rotate(60 32 32)"></ellipse>
  <ellipse cx="32" cy="32" rx="26" ry="10" stroke="currentColor" stroke-width="2.2" transform="rotate(120 32 32)"></ellipse>
  <circle cx="58" cy="32" r="2.6" fill="currentColor"></circle>
</svg>"""

SHELL = """<!doctype html>
<html lang="en" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<link rel="icon" href="favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="style.css">
<link href="https://api.fontshare.com/v2/css?f[]=satoshi@400,500,700&f[]=zodiak@400,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="vendor/katex/katex.min.css">
</head>
<body>
<a class="skip" href="#content">Skip to content</a>
<header>
  <div class="container-wide nav">
    <a class="brand" href="index.html" aria-label="Atomic Theory Atlas home">{logo}<strong>Atomic&nbsp;Theory&nbsp;Atlas</strong></a>
    <nav class="navlinks" aria-label="Primary">{navlinks}</nav>
    <button class="theme-toggle" data-theme-toggle aria-label="Switch theme">&#9790;</button>
  </div>
</header>
<main id="content">
{body}
</main>
<footer class="foot">
  <div class="container">
    <p class="small muted">Atomic Theory Atlas &mdash; an educational reference. Every equation is tagged <span class="pill stated">Stated</span> (quoted from a cited standard reference) or <span class="pill derived">Derived here</span> (algebra or numerics carried out on this site and shown step by step). Numerical constants follow CODATA 2022 via NIST<a class="cite" href="references.html#r14">[14]</a>; unit definitions follow the BIPM SI Brochure<a class="cite" href="references.html#r16">[16]</a>.</p>
    <p class="small muted">All in-body bracketed numbers link to the <a href="references.html">IEEE-style reference table</a>.</p>
  </div>
</footer>
<script src="vendor/katex/katex.min.js"></script>
<script src="vendor/katex/contrib/auto-render.min.js"></script>
<script>
  renderMathInElement(document.body, {{
    delimiters: [
      {{left: '\\\\[', right: '\\\\]', display: true}},
      {{left: '$$', right: '$$', display: true}},
      {{left: '\\\\(', right: '\\\\)', display: false}}
    ],
    ignoredTags: ['script','noscript','style','textarea','pre','code','option'],
    throwOnError: false
  }});
</script>
<script src="script.js"></script>
</body>
</html>
"""

FAVICON = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">
<rect width="64" height="64" rx="12" fill="#0f5f66"/>
<g stroke="#f7f6f2" stroke-width="3">
<ellipse cx="32" cy="32" rx="22" ry="9"/>
<ellipse cx="32" cy="32" rx="22" ry="9" transform="rotate(60 32 32)"/>
<ellipse cx="32" cy="32" rx="22" ry="9" transform="rotate(120 32 32)"/>
</g>
<circle cx="32" cy="32" r="4" fill="#f7f6f2"/>
</svg>"""

# ----------------------------------------------------------------------------
# Timeline data.  cat: people | orbital | timing | macro
# ----------------------------------------------------------------------------
ICON = {
    "people": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 21c0-3.9 3.4-6 7.5-6s7.5 2.1 7.5 6"/></svg>',
    "orbital": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="2"/><ellipse cx="12" cy="12" rx="9.5" ry="4"/><ellipse cx="12" cy="12" rx="9.5" ry="4" transform="rotate(60 12 12)"/></svg>',
    "timing": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7.5V12l3 2"/></svg>',
    "macro": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M2 15c2.5 0 2.5-6 5-6s2.5 6 5 6 2.5-6 5-6 2.5 6 5 6"/></svg>',
}

EVENTS = [
    (1808, "Dalton — chemical atomic theory", "people",
     "Fixed mass ratios in compounds are explained by discrete, indivisible atoms of each element.",
     "Wikipedia", "https://en.wikipedia.org/wiki/John_Dalton"),
    (1859, "Kirchhoff & Bunsen — spectroscopy", "macro",
     "Each element emits a fixed set of sharp lines, turning spectra into a fingerprint of atomic structure.",
     "Britannica", "https://www.britannica.com/science/spectroscopy"),
    (1873, "Maxwell — Treatise on Electricity and Magnetism", "macro",
     "A complete classical field theory of light; the radiation that atoms emit and absorb.",
     "Wikipedia", "https://en.wikipedia.org/wiki/A_Treatise_on_Electricity_and_Magnetism"),
    (1884, "Heaviside — vector form of Maxwell's equations", "people",
     "Recast twenty coupled equations into the four vector equations engineers use, and introduced operational calculus and impedance.",
     "Physics Today", "https://physicstoday.aip.org/features/oliver-heaviside-a-first-rate-oddity"),
    (1885, "Balmer — empirical hydrogen series", "orbital",
     "An empirical formula for hydrogen's visible lines; later the n = 2 series of the Rydberg formula.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Balmer_series"),
    (1888, "Rydberg — general series formula", "orbital",
     "One constant, \u211c\u221e, organises every hydrogenic line, anticipating quantised energy levels.",
     "NIST CODATA", "https://physics.nist.gov/cgi-bin/cuu/Value?ryd"),
    (1896, "Zeeman — magnetic splitting of spectral lines", "orbital",
     "Spectral lines split in a magnetic field: the first direct evidence that atomic states carry magnetic moments and orientation.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Zeeman_effect"),
    (1897, "Thomson — discovery of the electron", "people",
     "Cathode-ray deflection gives a charge-to-mass ratio far larger than any ion: atoms have internal charged parts.",
     "Wikipedia", "https://en.wikipedia.org/wiki/J._J._Thomson"),
    (1900, "Planck — quantum hypothesis", "people",
     "Blackbody radiation is fitted only if oscillator energies are quantised in units of \\(h\\nu\\).",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1918/planck/facts/"),
    (1905, "Einstein — light quanta", "people",
     "The photoelectric effect requires that radiation itself be quantised, which later underpins stimulated emission.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1921/einstein/facts/"),
    (1911, "Rutherford — nuclear atom", "people",
     "Large-angle alpha scattering demands a tiny, massive, positively charged nucleus.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Ernest_Rutherford"),
    (1913, "Bohr — quantised hydrogen orbits", "orbital",
     "Angular momentum quantised in units of \\(\\hbar\\) reproduces the Balmer/Rydberg spectrum exactly for hydrogen.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1922/bohr/facts/"),
    (1916, "Sommerfeld — elliptical orbits and \u03b1", "orbital",
     "Adds a second quantum number and the fine-structure constant, giving the first account of fine structure.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Arnold_Sommerfeld"),
    (1917, "Einstein — stimulated emission coefficients", "timing",
     "The \\(A\\) and \\(B\\) coefficients that make masers and lasers possible are introduced on thermodynamic grounds.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Stimulated_emission"),
    (1922, "Stern & Gerlach — space quantisation", "orbital",
     "A silver beam splits into two, not a continuum: angular momentum projection is quantised and spin is two-valued.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Stern%E2%80%93Gerlach_experiment"),
    (1925, "Pauli — exclusion principle", "orbital",
     "No two electrons share all four quantum numbers, which is what makes shells, the periodic table, and chemistry.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1945/pauli/facts/"),
    (1925, "Uhlenbeck & Goudsmit — electron spin", "orbital",
     "A fourth, intrinsically half-integer quantum number \\(m_s=\\pm\\tfrac12\\) completes the orbital labelling scheme.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Spin_(physics)"),
    (1925, "Heisenberg — matrix mechanics", "people",
     "Observables become non-commuting matrices; spectra follow from operator algebra rather than orbits.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1932/heisenberg/biographical/"),
    (1926, "Schr\u00f6dinger — wave mechanics", "orbital",
     "The wave equation whose central-potential solutions are the orbitals \\(\\psi_{n\\ell m}=R_{n\\ell}Y_\\ell^m\\).",
     "Wikipedia", "https://en.wikipedia.org/wiki/Erwin_Schr%C3%B6dinger"),
    (1927, "Heisenberg — uncertainty principle", "people",
     "\\(\\Delta x\\,\\Delta p \\ge \\hbar/2\\) sets the size of the ground state and the natural width of every transition.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1932/heisenberg/biographical/"),
    (1927, "Born & Oppenheimer — nuclear/electronic separation", "people",
     "Nuclei are treated as slow relative to electrons, which is the basis of all molecular potential-energy surfaces.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Born%E2%80%93Oppenheimer_approximation"),
    (1928, "Dirac — relativistic electron equation", "orbital",
     "Spin and hydrogenic fine structure emerge automatically from a first-order relativistic wave equation.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Paul_Dirac"),
    (1928, "Hund — coupling rules for open shells", "orbital",
     "Empirical rules fix which \\(L\\), \\(S\\), \\(J\\) term of a configuration lies lowest.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Hund%27s_rules"),
    (1930, "Fock & Slater — self-consistent field with antisymmetry", "macro",
     "Determinantal wavefunctions turn the many-electron problem into a tractable mean-field one.",
     "LibreTexts", "https://chem.libretexts.org/Bookshelves/Physical_and_Theoretical_Chemistry_Textbook_Maps/Advanced_Theoretical_Chemistry_(Simons)/06%3A_Electronic_Structure/6.03%3A_The_Hartree-Fock_Approximation"),
    (1938, "Rabi — molecular-beam magnetic resonance", "timing",
     "Driving a transition in a beam measures its frequency directly: the ancestor of every atomic frequency standard.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1944/rabi/facts/"),
    (1947, "Lamb & Retherford — the Lamb shift", "people",
     "2s\u00bd and 2p\u00bd are not degenerate, which forces a full quantum field treatment of the bound electron.",
     "NIST", "https://physics.nist.gov/PhysRefData/Handbook/Tables/hydrogentable5.htm"),
    (1948, "Feynman, Schwinger & Tomonaga — renormalised QED", "people",
     "Finite predictions for the Lamb shift and the electron anomalous moment; Feynman diagrams enter physics.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1965/feynman/facts/"),
    (1949, "Ramsey — separated oscillatory fields", "timing",
     "Two short, phase-coherent interaction zones separated by a long drift give a linewidth set by the drift time.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1989/ramsey/facts/"),
    (1950, "Kastler — optical pumping", "timing",
     "Light is used to move population between sublevels, a general recipe for creating inversions.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/physics/1966/kastler/facts/"),
    (1951, "Ewen & Purcell — 21 cm hydrogen line detected", "timing",
     "The 1420.405751768 MHz ground-state hyperfine line of H I is observed, opening spectral-line radio astronomy.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Hydrogen_line"),
    (1954, "Gordon, Zeiger & Townes — the first maser", "timing",
     "State-selected NH\u2083 on the \\(J=K=3\\) inversion line at 23 870 MHz oscillates inside a cavity.",
     "Phys. Rev. 95, 282", "https://iramis.cea.fr/wp-content/uploads/2015/01/20150130TownesMaserPhysRev95_1954_282.pdf"),
    (1955, "Essen & Parry — first caesium beam clock", "timing",
     "A Ramsey-interrogated Cs-133 beam becomes the most reproducible frequency reference available.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Caesium_standard"),
    (1960, "Goldenberg, Kleppner & Ramsey — hydrogen maser", "timing",
     "Wall-coated storage bulbs give second-long interaction times and exceptional short-term stability.",
     "Harvard Physics", "https://www.physics.harvard.edu/sites/projects.iq.harvard.edu/files/physics/files/2022-maser.pdf"),
    (1965, "Kohn & Sham — density-functional equations", "macro",
     "The electron density replaces the many-body wavefunction, making solids and large molecules computable.",
     "Nobel Prize", "https://www.nobelprize.org/prizes/chemistry/1998/kohn/facts/"),
    (1965, "Weaver et al. — first astrophysical maser (OH, 1665 MHz)", "timing",
     "Naturally inverted OH in star-forming regions shows the maser process operating on galactic scales.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Astrophysical_maser"),
    (1966, "Allan — variance for frequency standards", "timing",
     "\\(\\sigma_y(\\tau)\\) becomes the standard way to state how a clock's stability improves with averaging time.",
     "Proc. IEEE", "https://ieeexplore.ieee.org/document/1446034"),
    (1967, "SI second redefined on the Cs-133 hyperfine transition", "timing",
     "The second becomes 9 192 631 770 periods of the unperturbed ground-state hyperfine radiation of Cs-133.",
     "BIPM", "https://www.bipm.org/en/si-base-units/second"),
    (1968, "Cheung et al. — interstellar NH\u2083 detected", "timing",
     "The same inversion transitions used in the first maser become a galactic thermometer.",
     "Wikipedia", "https://en.wikipedia.org/wiki/Ammonia"),
    (1969, "22.23508 GHz water maser discovered", "timing",
     "The \\(6_{16}\\!-\\!5_{23}\\) rotational line of H\u2082O becomes the brightest maser line in the radio sky.",
     "ApJ 368, 215", "https://ui.adsabs.harvard.edu/abs/1991ApJ...368..215N/abstract"),
    (2001, "Katori — optical lattice clock proposed", "timing",
     "Neutral atoms in a magic-wavelength lattice give optical-frequency references with \\(Q>10^{14}\\).",
     "Wikipedia", "https://en.wikipedia.org/wiki/Optical_lattice_clock"),
    (2021, "CIPM recommended optical frequencies updated", "timing",
     "Sr-87 fixed at 429 228 004 229 872.99 Hz and Yb-171 at 518 295 836 590 863.63 Hz as secondary representations of the second.",
     "arXiv:2401.14537", "https://arxiv.org/html/2401.14537v1"),
    (2024, "BESIII reports a glueball candidate, X(2370)", "macro",
     "A QCD side note rather than atomic physics, treated separately on this site.",
     "Phys.org", "https://phys.org/news/2024-05-evidence-glueballs-beijing-spectrometer-iii.html"),
]

CAT_LABEL = {
    "people": "Foundational theory &amp; people",
    "orbital": "Orbitals, quantum numbers &amp; structure",
    "timing": "Masing, resonance &amp; timing",
    "macro": "Many-body &amp; macroscopic models",
}


def build_timeline_rail():
    out = ['<div class="tl-scroll" role="group" aria-label="Scrollable timeline of atomic theory">',
           '<div class="tl-rail"><div class="tl-axis" aria-hidden="true"></div>']
    for i, (year, name, cat, desc, src, url) in enumerate(EVENTS):
        pos = "up" if i % 2 == 0 else "down"
        out.append(
            f'<div class="tl-item {pos} tl-cat-{cat}" data-cat="{cat}">'
            f'<a class="tl-card" href="{url}" target="_blank" rel="noopener noreferrer">'
            f'<span class="tl-year">{year}</span>'
            f'<span class="tl-name">{name}</span>'
            f'<span class="tl-desc">{desc}</span>'
            f'<span class="tl-src">{src} &#8599;</span>'
            f'</a>'
            f'<span class="tl-node" aria-hidden="true">{ICON[cat]}</span>'
            f'</div>'
        )
    out.append('</div></div>')
    return "\n".join(out)


def build_timeline_filters():
    chips = ['<div class="tl-controls" role="group" aria-label="Filter timeline by category">']
    for cat, label in CAT_LABEL.items():
        chips.append(f'<button class="chip" data-cat="{cat}" aria-pressed="false"><span class="dot {cat}"></span>{label}</button>')
    chips.append('</div>')
    return "\n".join(chips)


def build_event_table():
    rows = []
    for year, name, cat, desc, src, url in EVENTS:
        plain = re.sub(r'<[^>]+>', '', name)
        rows.append(
            f'<tr><td class="mono">{year}</td><td>{plain}</td><td>{CAT_LABEL[cat]}</td>'
            f'<td><a href="{url}" target="_blank" rel="noopener noreferrer">{src}</a></td></tr>'
        )
    return (
        '<div class="table-wrap"><table><caption>Every timeline entry in linear reading order, with the '
        'reputable source each marker links to. This table is the accessible, printable equivalent of the '
        'graphical rail above.</caption>'
        '<thead><tr><th style="width:5.5rem">Year</th><th>Event</th><th>Track</th><th>Linked source</th></tr></thead>'
        '<tbody>' + "".join(rows) + '</tbody></table></div>'
    )


def render(page, title, desc, body):
    links = []
    for href, label in NAV:
        cls = ' class="active" aria-current="page"' if href == page else ''
        links.append(f'<a href="{href}"{cls}>{label}</a>')
    out = SHELL.format(title=title, desc=desc, logo=LOGO, navlinks="".join(links), body=body)
    with open(os.path.join(SRC, page), "w") as f:
        f.write(out)
    return len(out)


PAGES = [
    ("index.html", "Atomic Theory Atlas — from QED to macroscopic models", "A cited reference on atomic theory: quantum electrodynamics, orbitals and quantum numbers, many-body methods, macroscopic effective models, and the atomic transitions used for masing and timekeeping."),
    ("timeline.html", "Graphical Timeline — Atomic Theory Atlas", "An interactive, non-overlapping timeline of atomic theory, orbital structure, and maser/atomic-clock milestones, with every marker linked to a reputable source."),
    ("qed.html", "QED & Relativistic Atomic Theory — Atomic Theory Atlas", "Schrodinger, Dirac, and QED treatments of the bound electron: fine structure, the Lamb shift, the anomalous magnetic moment, and renormalisation."),
    ("orbitals.html", "Atomic Orbitals, Quantum Numbers & Energy Levels — Atomic Theory Atlas", "Quantum numbers, angular modes and orientation of atomic orbitals, degeneracy, selection rules, and how level structure produces the transitions used for masing."),
    ("masers.html", "Masers & Atomic Clocks — Atomic Theory Atlas", "Stimulated emission, population inversion, maser gain and threshold, Ramsey interrogation, Allan variance, and the microwave and optical transitions used as timing references."),
    ("macro.html", "Macroscopic Models — Atomic Theory Atlas", "From atomic polarisability to permittivity, dispersion, Kramers-Kronig relations, Drude-Lorentz response, plasma frequency, and radiative transfer."),
    ("glueballs.html", "Glueballs — a QCD side note — Atomic Theory Atlas", "Glueballs in nonperturbative QCD: lattice predictions, the X(2370) candidate, and why they are not atomic-scale energy packets."),
    ("references.html", "References — Atomic Theory Atlas", "Full IEEE-style numbered reference list with direct links for every citation used across the Atomic Theory Atlas."),
]

if __name__ == "__main__":
    with open(os.path.join(SRC, "favicon.svg"), "w") as f:
        f.write(FAVICON)
    for page, title, desc in PAGES:
        part = os.path.join(PARTS, page.replace(".html", ".part.html"))
        body = open(part).read()
        body = body.replace("<!--TIMELINE_RAIL-->", build_timeline_rail())
        body = body.replace("<!--TIMELINE_FILTERS-->", build_timeline_filters())
        body = body.replace("<!--TIMELINE_TABLE-->", build_event_table())
        body = body.replace("<!--REFERENCES_TABLE-->", build_reference_table())
        body = body.replace("<!--REFERENCES_LEGEND-->", build_reference_counts())
        n = render(page, title, desc, body)
        print(f"{page:18s} {n:>7,} bytes")

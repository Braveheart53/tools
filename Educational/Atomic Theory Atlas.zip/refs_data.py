# -*- coding: utf-8 -*-
"""IEEE-style reference list for the Atomic Theory Atlas.

Each entry: (number, ieee_citation_html, category_key, url)
Categories: history, constants, standards, maser, structure, macro, qcd
"""

CAT_LABEL = {
    "history": "History &amp; biography",
    "constants": "Constants &amp; atomic data",
    "standards": "Time &amp; frequency standards",
    "maser": "Masers, lasers &amp; pumping",
    "structure": "Atomic structure &amp; spectroscopy",
    "macro": "Macroscopic electromagnetics",
    "qcd": "QCD &amp; glueballs",
}

REFS = [
 (1, 'J. Dalton, &ldquo;A New System of Chemical Philosophy,&rdquo; Manchester, 1808. Summarized in: <em>Encyclopaedia Britannica</em>, &ldquo;Atom.&rdquo;', 'history', 'https://www.britannica.com/science/atom'),
 (2, 'E. Rutherford, &ldquo;The Scattering of &alpha; and &beta; Particles by Matter and the Structure of the Atom,&rdquo; <em>Philos. Mag.</em>, vol. 21, pp. 669&ndash;688, 1911. Summarized in: <em>Encyclopaedia Britannica</em>, &ldquo;Atom.&rdquo;', 'history', 'https://www.britannica.com/science/atom'),
 (3, 'N. Bohr, &ldquo;On the Constitution of Atoms and Molecules,&rdquo; <em>Philos. Mag.</em>, vol. 26, pp. 1&ndash;25, 1913. Biographical summary: Nobel Prize outreach, &ldquo;Niels Bohr &mdash; Facts.&rdquo;', 'history', 'https://www.nobelprize.org/prizes/physics/1922/bohr/facts/'),
 (4, 'M. Planck, biographical article, Wikipedia, &ldquo;Max Planck.&rdquo;', 'history', 'https://en.wikipedia.org/wiki/Max_Planck'),
 (5, 'Nobel Prize outreach, &ldquo;Max Planck &mdash; Facts,&rdquo; Nobel Prize in Physics 1918.', 'history', 'https://www.nobelprize.org/prizes/physics/1918/planck/facts/'),
 (6, 'A. Einstein, biographical and prize material, Nobel Prize outreach, &ldquo;Albert Einstein &mdash; Facts,&rdquo; Nobel Prize in Physics 1921.', 'history', 'https://www.nobelprize.org/prizes/physics/1921/einstein/facts/'),
 (7, 'W. Heisenberg, &ldquo;Werner Heisenberg &mdash; Biographical,&rdquo; Nobel Prize outreach, Nobel Prize in Physics 1932.', 'history', 'https://www.nobelprize.org/prizes/physics/1932/heisenberg/biographical/'),
 (8, 'O. Heaviside, biographical article, <em>Encyclopaedia Britannica</em>, &ldquo;Oliver Heaviside.&rdquo;', 'history', 'https://www.britannica.com/biography/Oliver-Heaviside'),
 (9, 'D. Mattson, &ldquo;Oliver Heaviside: A First-Rate Oddity,&rdquo; <em>Physics Today</em>, Oct. 2012.', 'history', 'https://physicstoday.aip.org/features/oliver-heaviside-a-first-rate-oddity'),
 (10, 'J. R. Oppenheimer, biographical article, Wikipedia, &ldquo;J. Robert Oppenheimer.&rdquo;', 'history', 'https://en.wikipedia.org/wiki/J._Robert_Oppenheimer'),
 (11, 'Atomic Heritage Foundation, &ldquo;J. Robert Oppenheimer,&rdquo; AHF Nuclear Museum profile.', 'history', 'https://ahf.nuclearmuseum.org/ahf/profile/j-robert-oppenheimer/'),
 (12, 'R. P. Feynman, biographical and prize material, Nobel Prize outreach, &ldquo;Richard P. Feynman &mdash; Facts,&rdquo; Nobel Prize in Physics 1965.', 'history', 'https://www.nobelprize.org/prizes/physics/1965/feynman/facts/'),
 (13, 'National Institute of Standards and Technology, &ldquo;Hydrogen energy levels including the Lamb shift,&rdquo; NIST Physical Reference Data, Table 5.', 'constants', 'https://physics.nist.gov/PhysRefData/Handbook/Tables/hydrogentable5.htm'),
 (14, 'National Institute of Standards and Technology, &ldquo;CODATA Internationally Recommended Values of the Fundamental Physical Constants,&rdquo; 2022 adjustment.', 'constants', 'https://physics.nist.gov/cuu/Constants/'),
 (15, 'National Institute of Standards and Technology, &ldquo;Atomic Spectra Database (ASD),&rdquo; version 5.', 'constants', 'https://physics.nist.gov/asd'),
 (16, 'Bureau International des Poids et Mesures, &ldquo;SI Brochure: The International System of Units (SI),&rdquo; 9th ed.', 'standards', 'https://www.bipm.org/en/publications/si-brochure'),
 (17, 'Bureau International des Poids et Mesures, &ldquo;Definition of the second,&rdquo; SI base units.', 'standards', 'https://www.bipm.org/en/si-base-units/second'),
 (18, 'National Institute of Standards and Technology, &ldquo;SI Units &mdash; Time.&rdquo;', 'standards', 'https://www.nist.gov/pml/owm/si-units-time'),
 (19, 'Wikipedia, &ldquo;Caesium standard.&rdquo;', 'standards', 'https://en.wikipedia.org/wiki/Caesium_standard'),
 (20, 'Wikipedia, &ldquo;Atomic clock.&rdquo;', 'standards', 'https://en.wikipedia.org/wiki/Atomic_clock'),
 (21, 'Wikipedia, &ldquo;Charles H. Townes.&rdquo;', 'maser', 'https://en.wikipedia.org/wiki/Charles_H._Townes'),
 (22, 'J. Ament, &ldquo;Charles Townes &mdash; Nobel Laureate for Maser-Laser Work,&rdquo; <em>Proc. (Bayl. Univ. Med. Cent.)</em>, PMC3257993.', 'maser', 'https://pmc.ncbi.nlm.nih.gov/articles/PMC3257993/'),
 (23, 'Optica, &ldquo;Charles Hard Townes,&rdquo; History of Optics Biographies.', 'maser', 'https://www.optica.org/History/Biographies/bios/Charles-Hard-Townes'),
 (24, 'Harvard University Department of Physics, &ldquo;Unprecedented Spectral Purity: The Invention of the Hydrogen Maser&rdquo; (PDF).', 'maser', 'https://www.physics.harvard.edu/sites/projects.iq.harvard.edu/files/physics/files/2022-maser.pdf'),
 (25, 'S. R. Jefferts <em>et al.</em>, &ldquo;A historical review of U.S. contributions to the atomic redefinition of the SI second in 1967,&rdquo; <em>J. Res. Natl. Inst. Stand. Technol.</em>, vol. 122, art. 29, 2017 (PDF).', 'standards', 'https://nvlpubs.nist.gov/nistpubs/jres/122/jres.122.029.pdf'),
 (26, 'C. Morningstar, &ldquo;Update on Glueballs,&rdquo; arXiv:2502.02547, 2025.', 'qcd', 'https://arxiv.org/abs/2502.02547'),
 (27, 'Y. Huang <em>et al.</em>, &ldquo;Discovery of a Glueball-like Particle X(2370) at BESIII,&rdquo; arXiv:2503.13286, 2025.', 'qcd', 'https://arxiv.org/abs/2503.13286'),
 (28, 'Phys.org, &ldquo;Possible evidence of glueballs found during Beijing Spectrometer III experiments,&rdquo; May 7, 2024.', 'qcd', 'https://phys.org/news/2024-05-evidence-glueballs-beijing-spectrometer-iii.html'),
 (29, 'Xinhua, &ldquo;Chinese researchers confirm existence of glueball,&rdquo; Aug. 5, 2026.', 'qcd', 'https://english.news.cn/20260806/46e2ea38c55b4708bd169f8214bc2bf0/c.html'),
 (30, 'Wikipedia, &ldquo;Glueball.&rdquo;', 'qcd', 'https://en.wikipedia.org/wiki/Glueball'),
 (31, 'R. M. Martin, <em>Electronic Structure: Basic Theory and Practical Methods</em>. Cambridge, U.K.: Cambridge Univ. Press, 2004.', 'structure', 'https://global.oup.com/academic/product/electronic-structure-9780521782852'),
 (32, 'J. Simons, &ldquo;The Hartree-Fock Approximation,&rdquo; in <em>Advanced Theoretical Chemistry</em>, &sect;6.3, LibreTexts Chemistry.', 'structure', 'https://chem.libretexts.org/Bookshelves/Physical_and_Theoretical_Chemistry_Textbook_Maps/Advanced_Theoretical_Chemistry_(Simons)/06%3A_Electronic_Structure/6.03%3A_The_Hartree-Fock_Approximation'),
 (33, 'National Institute of Standards and Technology, &ldquo;SI Units &mdash; electromagnetic quantities,&rdquo; NIST CUU Units reference.', 'macro', 'https://physics.nist.gov/cuu/Units/'),
 (34, 'N. F. Ramsey, &ldquo;A Molecular Beam Resonance Method with Separated Oscillating Fields,&rdquo; <em>Phys. Rev.</em>, vol. 78, no. 6, pp. 695&ndash;699, 1950. Biographical summary: Nobel Prize outreach, &ldquo;Norman F. Ramsey &mdash; Facts.&rdquo;', 'standards', 'https://www.nobelprize.org/prizes/physics/1989/ramsey/facts/'),
 (35, 'D. W. Allan, &ldquo;Statistics of Atomic Frequency Standards,&rdquo; <em>Proc. IEEE</em>, vol. 54, no. 2, pp. 221&ndash;230, Feb. 1966.', 'standards', 'https://ieeexplore.ieee.org/document/1446034'),
 (36, 'J. Schwinger, biographical article, Nobel Prize outreach, &ldquo;Julian Schwinger &mdash; Facts,&rdquo; Nobel Prize in Physics 1965.', 'history', 'https://www.nobelprize.org/prizes/physics/1965/schwinger/facts/'),
 (37, 'D. J. Gross, H. D. Politzer, and F. Wilczek, prize material, Nobel Prize outreach, &ldquo;The Nobel Prize in Physics 2004.&rdquo;', 'qcd', 'https://www.nobelprize.org/prizes/physics/2004/summary/'),
 (38, 'Wikipedia, &ldquo;Kramers-Kronig relations.&rdquo;', 'macro', 'https://en.wikipedia.org/wiki/Kramers%E2%80%93Kronig_relations'),
 (39, 'J. P. Gordon, H. J. Zeiger, and C. H. Townes, &ldquo;Molecular Microwave Oscillator and New Hyperfine Structure in the Microwave Spectrum of NH<sub>3</sub>,&rdquo; <em>Phys. Rev.</em>, vol. 95, no. 1, pp. 282&ndash;284, 1954 (PDF).', 'maser', 'https://iramis.cea.fr/wp-content/uploads/2015/01/20150130TownesMaserPhysRev95_1954_282.pdf'),
 (40, 'H. S. Margolis <em>et al.</em>, &ldquo;The CIPM list of recommended frequency standard values: 2021 update,&rdquo; arXiv:2401.14537.', 'standards', 'https://arxiv.org/html/2401.14537v1'),
 (41, 'Wikipedia, &ldquo;Stimulated emission&rdquo; (Einstein <em>A</em> and <em>B</em> coefficients).', 'maser', 'https://en.wikipedia.org/wiki/Stimulated_emission'),
 (42, 'W. Pauli, prize material, Nobel Prize outreach, &ldquo;Wolfgang Pauli &mdash; Facts,&rdquo; Nobel Prize in Physics 1945.', 'history', 'https://www.nobelprize.org/prizes/physics/1945/pauli/facts/'),
 (43, 'E. Schr&ouml;dinger, biographical article, Wikipedia, &ldquo;Erwin Schr&ouml;dinger.&rdquo;', 'history', 'https://en.wikipedia.org/wiki/Erwin_Schr%C3%B6dinger'),
 (44, 'P. A. M. Dirac, biographical article, Wikipedia, &ldquo;Paul Dirac.&rdquo;', 'history', 'https://en.wikipedia.org/wiki/Paul_Dirac'),
 (45, 'I. I. Rabi, prize material, Nobel Prize outreach, &ldquo;Isidor Isaac Rabi &mdash; Facts,&rdquo; Nobel Prize in Physics 1944.', 'history', 'https://www.nobelprize.org/prizes/physics/1944/rabi/facts/'),
 (46, 'J. Simons and J. Nichols, &ldquo;Atomic structure and the central-field approximation,&rdquo; in <em>Quantum Mechanics in Chemistry</em>, LibreTexts Chemistry.', 'structure', 'https://chem.libretexts.org/Bookshelves/Physical_and_Theoretical_Chemistry_Textbook_Maps/Quantum_Mechanics__in_Chemistry_(Simons_and_Nichols)'),
 (47, 'National Institute of Standards and Technology, &ldquo;Rydberg constant,&rdquo; CODATA value page.', 'constants', 'https://physics.nist.gov/cgi-bin/cuu/Value?ryd'),
 (48, 'Wikipedia, &ldquo;Atomic orbital&rdquo; (spherical harmonics and real orbital combinations).', 'structure', 'https://en.wikipedia.org/wiki/Atomic_orbital'),
 (49, 'Wikipedia, &ldquo;Zeeman effect.&rdquo;', 'structure', 'https://en.wikipedia.org/wiki/Zeeman_effect'),
 (50, 'Wikipedia, &ldquo;Optical lattice clock&rdquo; and blackbody-radiation / Stark shift systematics.', 'standards', 'https://en.wikipedia.org/wiki/Optical_lattice'),
 (51, 'Wikipedia, &ldquo;Hyperfine structure.&rdquo;', 'structure', 'https://en.wikipedia.org/wiki/Hyperfine_structure'),
 (52, 'Wikipedia, &ldquo;Hydrogen line&rdquo; (the 21 cm H&nbsp;I line).', 'structure', 'https://en.wikipedia.org/wiki/Hydrogen_line'),
 (53, 'Wikipedia, &ldquo;Selection rule.&rdquo;', 'structure', 'https://en.wikipedia.org/wiki/Selection_rule'),
 (54, 'A. Kastler, prize material, Nobel Prize outreach, &ldquo;Alfred Kastler &mdash; Facts,&rdquo; Nobel Prize in Physics 1966 (optical pumping).', 'maser', 'https://www.nobelprize.org/prizes/physics/1966/kastler/facts/'),
 (55, 'Y. Nakano and K. Yoshida, water-maser 6<sub>16</sub>&ndash;5<sub>23</sub> transition at 22.235&nbsp;08&nbsp;GHz, <em>Astrophys. J.</em>, vol. 368, p. 215, 1991 (ADS abstract).', 'maser', 'https://ui.adsabs.harvard.edu/abs/1991ApJ...368..215N/abstract'),
 (56, 'S. M&uuml;ller <em>et al.</em>, methanol maser rest frequencies, <em>Astron. Astrophys.</em>, 2004 (PDF).', 'maser', 'https://www.aanda.org/articles/aa/pdf/2004/48/aa1384.pdf'),
 (57, 'Wikipedia, &ldquo;Astrophysical maser&rdquo; (OH, H<sub>2</sub>O, CH<sub>3</sub>OH and SiO lines).', 'maser', 'https://en.wikipedia.org/wiki/Astrophysical_maser'),
]


def short_host(url):
    h = url.split("//", 1)[-1].split("/", 1)[0]
    return h[4:] if h.startswith("www.") else h


def build_reference_table():
    rows = []
    for num, cite, cat, url in REFS:
        rows.append(
            '<tr id="r{n}"><td class="ref-num">[{n}]</td>'
            '<td class="ref-cite">{c}<div class="ref-link">'
            '<a href="{u}" target="_blank" rel="noopener noreferrer">{h}</a></div></td>'
            '<td><span class="ref-cat ref-cat-{k}">{cl}</span></td></tr>'.format(
                n=num, c=cite, u=url, h=short_host(url), k=cat, cl=CAT_LABEL[cat]
            )
        )
    return (
        '<div class="table-wrap"><table class="ref-table">'
        '<caption>Complete IEEE-style numbered reference list. Every bracketed citation in the '
        'body text of this site links to the matching row here; each row links out to the source. '
        'Rows are ordered by first appearance across the site.</caption>'
        '<thead><tr><th scope="col">No.</th><th scope="col">Reference</th>'
        '<th scope="col">Category</th></tr></thead><tbody>'
        + "".join(rows) + "</tbody></table></div>"
    )


def build_reference_counts():
    counts = {}
    for _, _, cat, _ in REFS:
        counts[cat] = counts.get(cat, 0) + 1
    items = []
    for cat, label in CAT_LABEL.items():
        items.append(
            '<li><span class="ref-cat ref-cat-{k}">{l}</span> '
            '<span class="mono small">{n}</span></li>'.format(
                k=cat, l=label, n=counts.get(cat, 0)
            )
        )
    return '<ul class="ref-legend">' + "".join(items) + "</ul>"

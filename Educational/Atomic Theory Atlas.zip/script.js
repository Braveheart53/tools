(function () {
  // ---- theme ----
  // Theme follows the operating-system preference and can be overridden for the
  // current page view. No browser storage is used, so the page also runs inside
  // sandboxed iframes where the storage APIs are unavailable.
  var root = document.documentElement;
  var prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
  var manual = false;
  var theme = prefersDark.matches ? 'dark' : 'light';
  root.setAttribute('data-theme', theme);
  prefersDark.addEventListener('change', function (e) {
    if (manual) return;
    theme = e.matches ? 'dark' : 'light';
    root.setAttribute('data-theme', theme);
    paint();
  });
  var btn = document.querySelector('[data-theme-toggle]');
  function paint() {
    if (btn) {
      btn.textContent = theme === 'dark' ? '\u2600' : '\u263E';
      btn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
    }
  }
  paint();
  if (btn) {
    btn.addEventListener('click', function () {
      manual = true;
      theme = theme === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', theme);
      paint();
    });
  }

  // ---- variable-definition disclosures ----
  document.querySelectorAll('.info').forEach(function (b) {
    b.addEventListener('click', function () {
      var el = document.getElementById(b.getAttribute('aria-controls'));
      if (!el) return;
      var opening = el.hasAttribute('hidden');
      if (opening) { el.removeAttribute('hidden'); } else { el.setAttribute('hidden', ''); }
      b.setAttribute('aria-expanded', String(opening));
      var lbl = b.querySelector('.info-label');
      if (lbl) lbl.textContent = opening ? 'Hide variables' : 'Define variables';
    });
  });

  // ---- timeline category filters ----
  var chips = document.querySelectorAll('.chip[data-cat]');
  if (chips.length) {
    chips.forEach(function (chip) {
      chip.addEventListener('click', function () {
        var on = chip.getAttribute('aria-pressed') === 'true';
        chip.setAttribute('aria-pressed', String(!on));
        var active = [];
        document.querySelectorAll('.chip[data-cat]').forEach(function (c) {
          if (c.getAttribute('aria-pressed') === 'true') active.push(c.getAttribute('data-cat'));
        });
        document.querySelectorAll('.tl-item').forEach(function (item) {
          var show = active.length === 0 || active.indexOf(item.getAttribute('data-cat')) !== -1;
          if (show) { item.removeAttribute('hidden'); } else { item.setAttribute('hidden', ''); }
        });
      });
    });
  }

  // ---- keyboard scrolling for the timeline rail ----
  var rail = document.querySelector('.tl-scroll');
  if (rail) {
    rail.setAttribute('tabindex', '0');
    rail.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowRight') { rail.scrollLeft += 280; e.preventDefault(); }
      if (e.key === 'ArrowLeft') { rail.scrollLeft -= 280; e.preventDefault(); }
    });
  }
})();

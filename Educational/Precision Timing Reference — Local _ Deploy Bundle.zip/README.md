# Precision Timing Reference — Distribution Bundle

This archive contains two versions of the same site. Pick the one that matches how you plan to use it.

## `local-only/` — open directly from your hard drive

Just double-click `local-only/index.html` (or drag it into a browser). No server, no Python, nothing to
install or run.

- Every download button on the Downloads page is a plain link straight to the real file sitting in this
  folder's own `downloads/` subfolder.
- Zip bundles (`timing_project_full_bundle.zip`, `sa_stability_tool.zip`) download normally when clicked.
- Plain text files (`.py`, `.md`, `.txt`) opened via `file://` will typically **open in the browser tab**
  instead of prompting a save dialog — this is standard browser behavior for local text files and is not a
  bug in the site. Use your browser's "Save Page As" (Ctrl/Cmd+S) once the file is open, or just browse
  directly to the `downloads/` folder in your file manager and copy what you need.
- Equations rendered with MathJax need one CDN script (`cdn.jsdelivr.net`) to load, so a working internet
  connection is required to see typeset math — everything else on the page works fully offline.

## `deploy-ready/` — for hosting on a web server

Use this version if you're putting the site on GitHub Pages, Netlify, a plain web server, or anywhere else
people load it over `http://`/`https://` instead of `file://`.

- Includes `api_server.py`, a small FastAPI backend that serves `/api/files` and `/download/<filename>`
  with a real `Content-Disposition: attachment` header — this is what forces a true "Save As" dialog for
  every file type (including `.py`/`.md`) instead of opening them inline, which a plain static host can't
  do on its own.
- If you run `api_server.py` alongside the static files, the Downloads page automatically uses it for
  forced downloads.
- If you deploy the static files **without** running `api_server.py` (e.g. a plain static host), the
  Downloads page detects that the API is unreachable and automatically falls back to plain links straight
  at the files in its own `downloads/` folder — so the page still works, just without the forced
  "Save As" behavior for text files.
- `BRIEF.md` / `ELECTRONICS_PAGE_BRIEF.md` are the original build briefs kept for reference; safe to delete
  before deploying if you don't want them public.

## Both versions include

- All 8 tutorial/reference pages (What Is Masing?, Hyperfine Structure, Zeeman Splitting, Maser Physics &
  Disturbance Analysis, Electronics Package, SA Stability & Phase-Noise Tool, Downloads, References).
- The full `downloads/` folder: all analysis scripts, validation scripts, documentation, and both zip
  bundles.
- The `assets/` folder: CSS, page-animation JS, and all figures/manuals (including the two Vremya-CH
  reference figures, kept for reference even though the electronics page now cites the Safran/T4Science
  iMaser 3000 as its second example maser).

Generated for the Timing project, August 2026.

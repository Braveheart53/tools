# Build Brief: "Precision Timing Reference & Tutorial" Website

## Purpose & Framing
Build a multi-page **reference-and-tutorial** website (not a project showcase) about hydrogen maser
physics and frequency-stability analysis, for an RF/microwave engineer / radio-astronomer audience
(VLA/VLBA/GBT background). Tone: rigorous, textbook/technical-reference, like an IEEE tutorial article
or NIST monograph — not marketing copy. Every claim needs an inline citation to a source in the
References list below. Assume the reader is technically literate but wants clear derivations and worked
numbers, not hand-waving.

Working directory: `/home/user/workspace/sa_conversation_site/` (git repo already initialized).
Existing assets already in place — DO NOT regenerate these, reuse them:
- `assets/figures/fig1_physics_package.png` … `fig7_slope_change_detection.png` (7 PNGs, described below)
- `downloads/` — 20 files: README.md (has old 20-entry IEEE ref table + LaTeX equation appendix),
  all `.py` scripts, `requirements.txt`, `sa_stability_tool.zip`, `timing_project_full_bundle.zip`
- `api_server.py` — FastAPI backend already written (110 lines) with `/api/files`, `/api/source/{filename}`,
  `/download/{filename}` (forces download via Content-Disposition). NOT yet started/tested — start it with
  `start_server` and verify `/api/files` and one `/download/...` route respond before wiring the Downloads page.

## Design System (already decided — implement exactly)
- **Base**: use the standard base.css from the website-building skill (`shared/01-design-tokens.md`) —
  fluid `clamp()` type scale (`--text-xs` … `--text-hero`), 4px spacing scale (`--space-1`…`--space-32`),
  OKLCH-friendly variable structure, light+dark mode via `[data-theme]` attribute + toggle button (see
  skill file for the exact toggle JS snippet), reduced-motion media query, focus-visible outlines.
- **Typography**: "Technical / developer / data" pairing — **JetBrains Mono** (Google Fonts) for
  headings/display/code, **Inter** or **General Sans** (Fontshare, preferred) for body text. Load via
  CDN `<link>` tags, define `--font-display` and `--font-body`.
- **Palette — lab-notebook / scientific aesthetic** (NOT the Nexus fallback, NOT purple/blue AI-gradient
  look). Light mode: cream/paper background (~`#f7f4ec`), deep navy-black ink text (~`#1a2332`), signal-blue
  primary accent `#2b6cb0` (hover `#2c5282`, active `#1e3a5f`). Secondary/warning accent amber/orange
  `#dd6b20` (hover `#c05621`). Success green `#38a169`/`#2f855a`. Purple `#805ad5` for GPSDO-band data.
  Red `#e53e3e`/`#c53030` for GPS common-view band. Navy `#2c5282` for pressure data. These exact hues
  must carry over into any new charts/diagrams for visual continuity with the existing 7 figures, which
  already use this palette. Build a full dark-mode variant (dark paper → near-black `#12161c` background,
  same accent hues lightened for contrast, WCAG AA).
- Code blocks: use `highlight.js` via CDN for Python syntax highlighting on any embedded snippets.
- Content width: cap reading columns at ~720-760px for long-form tutorial text; wider (1100-1200px) for
  figures/tables/diagrams.

## Site Architecture (multi-page, static HTML/CSS/JS — no framework)
Use a shared header/footer to keep navigation consistent — either (a) a small build script that assembles
each page from `templates/header.html` + page content + `templates/footer.html`, or (b) a runtime JS
partial-injector (`fetch('/partials/nav.html')` into a `<div id="site-nav">`) — either is fine, pick
whichever is more reliable to maintain; document the choice. Nav must expose ALL pages, grouped into three
sections: **Tutorial**, **Tools & Analysis**, **Reference**.

Pages to build (all new except the two "reuse existing content" ones):

1. **`index.html`** — Hub / overview. Framing: "A hands-on reference and tutorial on hydrogen maser
   physics and the frequency-stability tools used to characterize precision oscillators." Short intro,
   then a card-grid linking to every page below, organized by the three nav sections. Set the tone for
   the whole site as a textbook, not a portfolio.

2. **`pages/hyperfine-structure.html`** — "Hyperfine Structure of Atomic Hydrogen"
   Content (all facts below are verified — cite as listed):
   - Definition: hyperfine structure arises from the interaction between the electron's magnetic moment
     and the proton's (nuclear) magnetic moment, both spin-1/2 particles, in the hydrogen 1S ground state.
     Zero-field Hamiltonian: \(\hat H = A\,\boldsymbol{\sigma}_e\cdot\boldsymbol{\sigma}_p\).
     [Feynman Lectures Vol. III, Ch. 12, https://www.feynmanlectures.caltech.edu/III_12.html]
   - Four basis product states of two spin-1/2 particles combine into a spin-triplet (F=1, three states,
     energy +A) and a spin-singlet (F=0, one state, energy −3A):
     F=1 triplet: \(|{+}{+}\rangle\) (mF=+1), \(\tfrac{1}{\sqrt2}(|{+}{-}\rangle+|{-}{+}\rangle)\) (mF=0),
     \(|{-}{-}\rangle\) (mF=−1); F=0 singlet: \(\tfrac{1}{\sqrt2}(|{+}{-}\rangle-|{-}{+}\rangle)\).
     [Feynman III-12]
   - Zero-field transition energy \(\Delta E = 4A\); frequency \(\nu_0 = 1{,}420{,}405{,}751.800 \pm 0.028\)
     Hz — the famous "21-cm line" (\(\lambda \approx 21.1\) cm). [Feynman III-12] Corroborate with
     [NIST, "Time and Frequency from A to Z" — H, https://www.nist.gov/pml/time-and-frequency-division/popular-links/time-frequency-z/time-and-frequency-z-h]
     which states the H-maser resonance is 1,420,405,752 Hz.
   - Radio-astronomy relevance: predicted 1944 (van de Hulst), first observed 1951 (Ewen & Purcell,
     Harvard) — the 21-cm line is the primary tracer of neutral atomic hydrogen (HI) in the interstellar
     medium and is observed routinely with VLA/GBT-class radio telescopes; tie this explicitly to the
     user's radio-astronomy background. [HyperPhysics, 21-cm line — use as a supplementary/tertiary
     source only, http://hyperphysics.phy-astr.gsu.edu/hbase/quantum/h21.html — cross-checked against
     the primary Feynman value above, do not present it as the primary citation]
   - Behavior in an external field \(B\hat z\) (Breit-Rabi formula) — general form for J=1/2, nuclear
     spin I=1/2:
     \(E(F,m_F) = hA\left[-\tfrac14 + \tfrac{2\gamma}{1-\gamma}m_F X \pm \tfrac{2I+1}{4}\sqrt{1+\tfrac{4m_F}{2I+1}X+X^2}\right]\),
     where \(X \equiv \mu_B B(g_J-g_I')/[(I+\tfrac12)hA]\), first derived by Breit & Rabi (1931).
     [NIST, "Atomic Beam Frequency Standards," https://tf.nist.gov/general/pdf/4.pdf — Breit-Rabi
     derivation; also confirmed by NIST, Phys. Rev. A 84, 012510 (2011), https://tf.nist.gov/general/pdf/2523.pdf]
   - Weak-field limit (Feynman's explicit hydrogen-specific forms, useful for a worked example):
     \(E_I = A+\mu B\), \(E_{II} = A-\mu B\) (F=1, mF=±1 — linear in B),
     \(E_{III} = A\{-1+2\sqrt{1+\mu'^2B^2/4A^2}\}\), \(E_{IV} = -A\{1+2\sqrt{1+\mu'^2B^2/4A^2}\}\)
     (mixing of the two mF=0 states — quadratic in B at low field), with \(\mu=-(\mu_e+\mu_p)\),
     \(\mu'=-(\mu_e-\mu_p)\), both ≈ one Bohr magneton. [Feynman III-12]
   - Ground-state sublevels named per the H-maser literature: (F=1,mF=+1), (F=1,mF=0), (F=1,mF=−1),
     (F=0,mF=0); the maser's "clock transition" is (F=1,mF=0)→(F=0,mF=0).
     [Kleppner, Berg, Crampton, Ramsey, Vessot, Peters, Vanier, "Hydrogen-Maser Principles and
     Techniques," Phys. Rev. 138, A972–A983 (1965), DOI: 10.1103/PhysRev.138.A972]
   - **Animation required**: an interactive/CSS-or-Canvas energy-level diagram showing the 4 sublevels
     at B=0 (three degenerate at +A, one at −3A) smoothly splitting/moving as a slider or auto-playing
     timeline increases B — the 3 states from +A fan out linearly (slopes +μ, 0, −μ) while the −3A state
     bends slightly upward (quadratic). Style: matches the existing `fig3_zeeman_curve.png` color
     conventions (blue/orange/green/purple). Also include a simple vector-model illustration (SVG) of
     electron spin + proton spin coupling into F=0 (antiparallel/singlet) vs F=1 (parallel/triplet).

3. **`pages/zeeman-splitting.html`** — "The Zeeman Effect in the Hydrogen Clock Transition"
   Content:
   - General Zeeman effect definition: splitting of atomic energy levels in an external magnetic field
     due to interaction of magnetic moments with the field, lifting the mF degeneracy present at B=0.
   - Apply specifically to the H-maser clock transition (F=1,mF=0)→(F=0,mF=0): because both sublevels
     have mF=0, there is **no linear (first-order) Zeeman shift** — the shift is purely quadratic in B.
     This is why hydrogen masers are relatively insensitive to magnetic field compared to, e.g., cesium.
   - Quantitative formula (already used and validated in `zeeman_curve.py`, keep the exact same value —
     it was previously fact-checked and corrected 10×): \(\nu = \nu_0 + K_B H^2\), with
     \(K_B \approx 2750\) Hz/Oe² i.e. \(2.750\times10^{11}\) Hz/T² for the (F=1,mF=0)→(F=0,mF=0) transition,
     and equivalently the fractional-shift form \(\delta\nu/\nu_0 = 3.9\times10^{-6}\,H\,\Delta H\)
     (H, ΔH in oersted). [Kleppner, Goldenberg, Ramsey, "Theory of the Hydrogen Maser," Phys. Rev. 126,
     603–615 (1962), DOI: 10.1103/PhysRev.126.603; corroborated by Kleppner et al. 1965, Phys. Rev. 138,
     A972, DOI: 10.1103/PhysRev.138.A972]
   - Practical numbers: hydrogen masers typically operate with ambient/shielded fields ≤ 1 mOe (with
     poorly demagnetized shields sometimes needing a uniform bias field ≥ 5 mOe); fields as low as
     6×10⁻⁴ Oe have been achieved. [Kleppner et al. 1965]
   - Reuse and re-present `assets/figures/fig3_zeeman_curve.png` (quadratic Zeeman shift vs C-field) and
     `assets/figures/fig2_disturbance_impact.png` / `fig4_freq_shift_absolute.png` with full captions and
     citations, linking this theory page to the practical disturbance-analysis page (#6 below).
   - **Animation required**: a small interactive plot (Canvas/SVG/Chart.js, using the toolkit already
     vetted in `07-toolkit.md`) showing the quadratic curve \(\Delta\nu = K_B H^2\) with a draggable/slider
     H value, updating a numeric readout of Δν in real time — visually distinguish this from the linear
     splitting shown on the hyperfine-structure page's animation (same color palette).

4. **`pages/what-is-a-maser.html`** — "What Is Masing? Maser vs. Laser, Defined"
   Content:
   - **MASER = Microwave Amplification by Stimulated Emission of Radiation** — acronym coined in the
     1954-55 papers below. "Masing" is the verb form (parallel to "lasing") describing the stimulated-
     emission gain process occurring in a "masing medium." [NIST, "Time and Frequency from A to Z" — M,
     https://www.nist.gov/pml/time-and-frequency-division/popular-links/time-frequency-z/time-and-frequency-z-m]
   - Physical mechanism: population inversion (more atoms/molecules in the upper energy state than the
     lower one) + stimulated emission (Einstein, 1916) → an incident photon at the transition frequency
     triggers emission of a coherent, in-phase photon, amplifying the microwave field; place inside a
     resonant cavity for feedback → oscillator. [Physics APS, "Invention of the Maser and Laser,"
     https://physics.aps.org/story/v15/st4]
   - History: first working maser — ammonia (NH3) beam maser, Townes/Gordon/Zeiger, Columbia University,
     1954 (10 nanowatt output), theory paper "Molecular Microwave Oscillator and New Hyperfine Structure
     in the Microwave Spectrum of NH3," Phys. Rev. 95, 282 (1954), DOI: 10.1103/PhysRev.95.282; full
     device paper "The Maser—New Type of Microwave Amplifier, Frequency Standard, and Spectrometer,"
     J. P. Gordon, H. J. Zeiger, C. H. Townes, Phys. Rev. 99, 1264–1274 (1955), DOI:
     10.1103/PhysRev.99.1264 — this paper coined the acronym MASER. [Physics APS story above; primary
     papers cited directly]
   - Hydrogen maser specifically: invented 1960 by Kleppner, Goldenberg, Ramsey at Harvard — first
     reported in Goldenberg, Kleppner, Ramsey, "Atomic Hydrogen Maser," Phys. Rev. Lett. 5, 361 (1960);
     full theory in Kleppner, Goldenberg, Ramsey, Phys. Rev. 126, 603 (1962), DOI:
     10.1103/PhysRev.126.603. Population inversion is established between the (F=1,mF=0) and
     (F=0,mF=0) hyperfine sublevels via magnetic state selection (hexapole magnet) before atoms enter a
     Teflon-coated storage bulb inside a high-Q microwave cavity tuned to 1420.405751768 MHz.
     [Frontiers in Physics, "Review of the development of the hydrogen maser" (2022), DOI:
     10.3389/fphy.2022.995361, https://www.frontiersin.org/journals/physics/articles/10.3389/fphy.2022.995361/full]
   - How "masing" relates to "maser": maser is the *device/noun*; masing is the *stimulated-emission gain
     process* occurring inside it — same relationship as "laser" (device) to "lasing" (process). Note that
     recent literature (e.g. solid-state maser research) still uses "masing action" as the standard term.
     [arXiv:2301.01927, https://arxiv.org/abs/2301.01927 — uses "masing actions" alongside "lasing
     actions," corroborating the terminology]
   - Nobel note: Townes shared the 1964 Nobel Prize in Physics (with Basov and Prokhorov) for
     fundamental work leading to the maser/laser. [Physics APS story]
   - **Animation required**: a simple photon-cascade/population-inversion animation — 2-3 atoms in a
     cavity, upper-state (F=1,mF=0) atoms shown getting triggered by an incident photon and emitting a
     coherent second photon in phase, with photon count growing — CSS/Canvas, matches site palette.

5. **`pages/maser-physics-analysis.html`** — "Environmental Disturbances & Frequency-Shift Analysis"
   Reuse and present the existing analysis from `/home/user/workspace/maser_analysis/` scripts and figures
   (already fact-checked in this project). Present each figure with a full caption, the governing
   equation, and a link back to `zeeman-splitting.html` for the underlying physics:
   - `fig1_physics_package.png` — H-maser physics package architecture (PLL-locked outputs, corrected
     architecture from earlier in this project — NOT direct RF, outputs are phase-locked to the atomic
     resonance).
   - `fig2_disturbance_impact.png` — Magnetic Disturbance Impact Comparison (dual G/T units).
   - `fig3_zeeman_curve.png` — Quadratic Zeeman Shift vs C-field (dual G/T units) — cross-reference to
     zeeman-splitting.html.
   - `fig4_freq_shift_absolute.png` — Estimated Absolute Frequency Shift from Magnetic Disturbances.
   - `fig5_gps_timing_drift.png` — Equivalent Maser 1PPS Timing Drift vs GPS.
   - `fig6_thermal_pressure_slope.png` — Equivalent Maser Timing Drift from Temperature and Pressure.
   - `fig7_slope_change_detection.png` — Automated Slope-Change Detector validation output.
   Include short code excerpts (via highlight.js) from `slope_change_detector.py` and link to the
   Downloads page for the full scripts. Cite [Howe, "ThêoH," Metrologia 43, S17 (2006), DOI:
   10.1088/0026-1394/43/4/S17] for the slope-change/bias-function methodology.

6. **`pages/sa-stability-tool.html`** — "SA Stability & Phase-Noise Analysis Tool"
   Present the tool documented in `downloads/README.md` — module list (`stability_core.py`,
   `phase_noise.py`, `sa_convert.py`, `stable32_export.py`, `veusz_export.py`, `gui_app.py`, validation
   scripts), the LaTeX equation appendix from that README (Allan variance/deviation, overlapping ADEV,
   modified ADEV, Hadamard variance, phase-noise L(f) conversions — pull the exact equations out of
   `downloads/README.md`, do not invent new ones), and a validation-results summary table (from the
   `validate_*.py` scripts). Link to Downloads for the zip.

7. **`pages/references.html`** — "References (IEEE Format)"
   ONE consolidated, numbered IEEE-style reference list covering the ENTIRE site. Merge the original
   20-entry table from `downloads/README.md` with the new sources introduced on pages 2-5 above (listed
   with exact URLs/DOIs in this brief). Deduplicate (e.g., the two Kleppner hydrogen-maser papers appear
   on multiple pages — cite once here). Group into logical sections with anchor IDs (e.g. `#nist-bipm`,
   `#maser-hyperfine`, `#stability-analysis`, `#software-tools`, `#equipment-manuals`) so other pages can
   deep-link to specific entries (e.g. `references.html#ref-12`). Every entry must have a real, clickable
   URL/DOI — no bare titles. Order: NIST/BIPM/government sources first, then peer-reviewed journals
   (IEEE/APS/Metrologia/Frontiers), then manufacturer manuals/docs, then software/tool docs — this order
   matches the project's stated source-weighting instructions.

8. **`pages/downloads.html`** — "Downloads"
   List every file in `downloads/` with a description (pull from `FILE_META` in `api_server.py`) and a
   forced-download link hitting `/download/{filename}` (NOT the static `download` attribute — verify this
   actually triggers a real download in the deployed preview, since `shared/19-backend.md` warns the
   static-site proxy breaks the HTML `download` attribute for binary/text files). Include a "Download
   Everything" card at the top linking to `timing_project_full_bundle.zip`. Group into: Analysis Scripts,
   SA Stability Tool Modules, Validation Scripts, Full Bundles.

## Cross-linking requirement
Every page must link forward/backward through the tutorial sequence (Hyperfine Structure →
Zeeman Splitting → What Is a Maser? → Disturbance Analysis → SA Tool) with "Next/Previous" nav at the
bottom, PLUS every technical claim on every page must link inline to its numbered entry on
`references.html`.

## Backend wiring
1. Run `pplx-tool start_server` (or equivalent) to launch `api_server.py` on port 8000 in the background.
2. Verify `GET /api/files` returns JSON and `GET /download/<a real filename>` returns a file with
   `Content-Disposition: attachment` header (curl -I check).
3. Wire `downloads.html` to call these endpoints (or hardcode the file list from `FILE_META` directly in
   HTML if that's simpler/more robust for a static-ish deploy — your call, document which approach and why).
4. When deploying with `deploy_website`, follow `shared/19-backend.md` for the `__PORT_8000__` placeholder
   pattern so the backend origin resolves correctly in the sandboxed preview.

## QA requirements
- This is a complex multi-page site with animations and interactive elements → Playwright QA is
  MANDATORY per the website-building skill. Screenshot every page at desktop (1280px+) and mobile (375px),
  light AND dark mode for at least the homepage and one tutorial page. Check: text doesn't overflow/wrap
  awkwardly, animations run without layout shift, all inline citations resolve to a real anchor on
  references.html, all download links actually force a download (not just navigate).
- Do NOT invent any numeric physics value not present in this brief or in the existing `downloads/README.md`
  / `maser_analysis` scripts. If a page needs a number not listed here, search for it and cite the source
  properly — do not guess.
- `git add -A && git commit` after each major milestone (per skill instructions).

## Master citation list for `references.html` (all URLs verified reputable — NIST/APS/AIP/NASA/Metrologia/arXiv/Frontiers/manufacturer docs; DO NOT include plain Wikipedia; HyperPhysics only as a clearly-labeled supplementary/tertiary source on the hyperfine page, never as a primary reference)

**Government / standards bodies (cite first):**
- NIST, "Time and Frequency from A to Z — H," https://www.nist.gov/pml/time-and-frequency-division/popular-links/time-frequency-z/time-and-frequency-z-h
- NIST, "Time and Frequency from A to Z — M," https://www.nist.gov/pml/time-and-frequency-division/popular-links/time-frequency-z/time-and-frequency-z-m
- NIST, "Atomic Beam Frequency Standards" (Breit-Rabi formula), https://tf.nist.gov/general/pdf/4.pdf
- NIST, Phys. Rev. A 84, 012510 (2011) [Breit-Rabi corroboration], https://tf.nist.gov/general/pdf/2523.pdf
- NIST SP1065, https://tf.nist.gov/general/pdf/2220.pdf
- NIST SP559-predecessor, https://tf.nist.gov/general/pdf/461.pdf
- NIST/Howe & Tasset reports: https://tf.nist.gov/general/pdf/1894.pdf , https://tf.boulder.nist.gov/general/pdf/1979.pdf
- NASA TM / NTRS Kleppner et al. 1965 reprint, https://ntrs.nasa.gov/citations/19650041605

**Peer-reviewed journals:**
- Gordon, J.P., Zeiger, H.J., Townes, C.H., "Molecular Microwave Oscillator and New Hyperfine Structure
  in the Microwave Spectrum of NH3," Phys. Rev. 95, 282 (1954). DOI: 10.1103/PhysRev.95.282
- Gordon, J.P., Zeiger, H.J., Townes, C.H., "The Maser—New Type of Microwave Amplifier, Frequency
  Standard, and Spectrometer," Phys. Rev. 99, 1264–1274 (1955). DOI: 10.1103/PhysRev.99.1264
  (https://link.aps.org/doi/10.1103/PhysRev.99.1264)
- Goldenberg, H.M., Kleppner, D., Ramsey, N.F., "Atomic Hydrogen Maser," Phys. Rev. Lett. 5, 361 (1960).
- Kleppner, D., Goldenberg, H.M., Ramsey, N.F., "Theory of the Hydrogen Maser," Phys. Rev. 126, 603–615
  (1962). DOI: 10.1103/PhysRev.126.603 (https://harvest.aps.org/v2/journals/articles/10.1103/PhysRev.126.603/fulltext)
- Kleppner, D., Berg, H.C., Crampton, S.B., Ramsey, N.F., Vessot, R.F.C., Peters, H.E., Vanier, J.,
  "Hydrogen-Maser Principles and Techniques," Phys. Rev. 138, A972–A983 (1965). DOI:
  10.1103/PhysRev.138.A972 (https://link.aps.org/doi/10.1103/PhysRev.138.A972)
- Ramsey, N.F., "The Atomic Hydrogen Maser," Metrologia 1(1), 7 (1965).
  http://www.leapsecond.com/history/1965-Metrologia-v1-n1-Ramsey.pdf
- Howe, D.A., "ThêoH: A Hybrid, High-Confidence Statistic that Improves on the Allan Deviations for
  Separating White and Flicker PM," Metrologia 43, S17 (2006). DOI: 10.1088/0026-1394/43/4/S17
- Frontiers in Physics, "Review of the development of the hydrogen maser" (2022). DOI:
  10.3389/fphy.2022.995361, https://www.frontiersin.org/journals/physics/articles/10.3389/fphy.2022.995361/full
- Welch, "A statistical relationship between spectral density and frequency stability" (1967). DOI:
  10.1109/TAU.1967.1161901
- IEEE Std 1139-2008 (frequency/time terminology standard)

**Physics education / research news (trusted secondary):**
- Physics (APS), "Invention of the Maser and Laser," https://physics.aps.org/story/v15/st4
- Feynman, Leighton, Sands, The Feynman Lectures on Physics, Vol. III, Ch. 12, "The Hyperfine Splitting
  in Hydrogen," https://www.feynmanlectures.caltech.edu/III_12.html
- arXiv:2301.01927 (masing-action terminology corroboration), https://arxiv.org/abs/2301.01927
- HyperPhysics, 21-cm line (supplementary only), http://hyperphysics.phy-astr.gsu.edu/hbase/quantum/h21.html

**Manufacturer / tool documentation:**
- Microchip MHM-2010/MSM-2010 User Guide Rev J.
- Stable32 Manual, http://www.stable32.com/Manual154.pdf ; app note
  http://www.wriley.com/Learn%20Frequency%20Stability%20Analysis%20Using%20Stable32.pdf
- Keysight PXA/MXA phase-noise measurement guide.
- R&S FSWP manual.
- Allantools docs, https://allantools.readthedocs.io/en/latest/functions.html
- PySide6 docs, https://doc.qt.io/qtforpython-6/
- Veusz docs, https://veusz.github.io/docs/
- Matplotlib, DOI: 10.1109/MCSE.2007.55
- Rubiola, E., Phase Noise and Frequency Stability in Oscillators, Cambridge Univ. Press (2008). DOI:
  10.1017/CBO9780511812798
- NBS TN394 / Barnes et al. 1971 (Characterization of Frequency Stability).
- Purdue ThêoH bias paper, https://engineering.purdue.edu/oxidemems/conferences/fcs2006/PDFs/Papers/145_6180.pdf

## Deliverable
A deployed preview via `deploy_website()` of the complete site, plus a short summary of: final nav
structure, which pages got animations, how the backend downloads were wired, and any physics numbers that
could NOT be verified (flag clearly — do not silently omit or guess).

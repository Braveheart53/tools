# New Page: Electronics Package — "Inside the Maser: Receiver, PLL & Frequency Chain"

**File:** `pages/electronics-package.html`
**Nav placement:** Tutorial section, insert after "Maser Physics & Disturbance Analysis" and before "SA Stability & Phase-Noise Tool" (or wherever the Tutorial nav group is — match existing nav pattern/order in other pages).
**Also add to:** `pages/references.html` consolidated IEEE reference list (append new sources below, keep existing numbering scheme, continue sequentially from the last reference number already used).

Match the established design system exactly (JetBrains Mono headings, Inter/General Sans body, lab-notebook palette, light/dark mode, same header/footer partials as the other 7 pages). Follow the same page anatomy/structure/typography as `pages/maser-physics-analysis.html` and `pages/what-is-a-maser.html` (read them for the exact pattern before writing this one).

## Page purpose (per user's explicit request)

The user asked: "Make sure you have a page that steps through the electronics package with diagrams and images from the maser manuals. Ensure you address where the 100 MHz output is multiplied from and where the LOs are generated, with what type of oscillator." This page must visually and textually answer that, using **real manual diagrams**, not generated illustrations, for the core block diagrams. Generated illustrations may supplement but must not replace the sourced manual figures.

## Images already extracted (use directly, do not regenerate)

All in `/home/user/workspace/sa_conversation_site/assets/manuals/` (already inside this project, just reference relative path `../assets/manuals/<file>` from pages/):

1. `mhm2010_fig2_block_diagram.png` — **PRIMARY HERO DIAGRAM**. Microsemi/Microchip MHM-2010 "Figure 2. Maser Block Diagram" — full labeled block diagram: MPG, Varactor Control, Receiver Amplifier (1420.405751 MHz, -105dBm typ, 1dB NF, 45dB gain/14MHz BW), L.O. Multiplier (-1dBm out), I.F. Strip, Temperature Control System, Phase Detector & 5 MHz VCO, 14-digit Synthesizer, Signal Buffers (5→10 MHz), Synchronous Detector, Cavity Register, Power Module, plus the physics package cutaway (storage bulb, cavity, state selector, source). Source: Microsemi/Microchip, "Atomic Hydrogen Maser MHM-2010 User's Guide, Rev J," Oct 2014, p.35, https://www.gb.nrao.edu/~fghigo/timer/MSMmaser/Maser_UG_75666-201_Rev_J.PDF
2. `mhm2010_fig1_elevation.png` — mechanical elevation/outline drawing. Same source, p.34.
3. `mhm2010_fig3_system_layout.png` — physical module layout showing "5 MHz Crystal" module location, Synthesizer Control, Data and I/O Electronics, Vacion Pumps, etc. Same source, p.36.
4. `mhm2010_fig4_physics_layout.png` — physics package cross-section (Bell Jar, Storage Bulb, State Selector, Source Bulb). Same source, p.37.
5. `mhm2010_fig5_stability.png` — Allan deviation stability plot. Same source, p.38.

Also available (not yet extracted as standalone crops — extract if time permits, else link to the source PDF page or describe in text with citation only):
- Vremya-CH VCH-1003M "Figure 4 PLL Unit circuit" (p.12 of manual) — explicit block diagram: VCO 5 MHz → Multiplier → outputs 100 MHz and 1400 MHz; Heterodyne receiver mixes 1420 MHz maser signal down to 405.751 kHz using the 1400 MHz LO from the Multiplier; Phase Detector (PD) compares against Synthesizer's 405.751xxxx kHz; Frequency divider produces 1PPS. Source: Vremya-CH, "VCH-1003M Active Hydrogen Maser Operations Manual 411141.032 OM," §4.3, http://www.heritek.com.cn/Private/Files/3505593a10526e3fabfc.pdf
- Vremya-CH "Figure 3 Physics Package Layout" (p.11) — cutaway showing Varactor, RF cavity, Storage bulb, Coupling loop, Receiving loop, Ferrit isolator, ion pumps, Nickel purifier, Beam stabilizer, HF Oscillator, 4-pole state selector. Same source, §4.2.
- If the subagent wants these as images, re-render with: `pdftoppm -f 12 -l 12 -r 300 -png /home/user/workspace/maser_manuals/vremya_vch1003m.pdf vremya_fig4` and `pdftoppm -f 11 -l 11 -r 300 -png /home/user/workspace/maser_manuals/vremya_vch1003m.pdf vremya_fig3`, then copy PNG into `assets/manuals/`. These pages render right-side-up already (no rotation needed) based on earlier inspection.

## Content outline (write full prose + captions; use IEEE-style inline citations matching the rest of the site's citation convention)

### 1. Intro paragraph
Frame the page: after the cavity produces its ~10⁻¹²–10⁻¹³ W microwave emission at 1,420,405,751.77 Hz [cite MHM-2010 UG, Ch.II §J, and NASA/IVS Diegel physics section], that signal must be received, down-converted, phase-locked to a stable crystal oscillator, and multiplied/buffered out to standard lab frequencies. This page walks through that electronics package end-to-end using manufacturer manual diagrams.

### 2. Section: "From Cavity to Receiver"
- Coupling/pickup loop extracts the weak 1420.405751 MHz signal from the cavity (10⁻¹² – 10⁻¹³ W per NRAO tutorial slide 6 / Diegel item 8; 100–200 fW per Vremya-CH §4.2).
- Feeds a low-noise heterodyne receiver. MHM-2010 Receiver Amplifier spec: 45 dB gain, 14 MHz bandwidth, 1 dB noise figure, -105 dBm typical input [MHM-2010 UG Fig.2].
- Embed **Figure 2 Block Diagram (mhm2010_fig2_block_diagram.png)** here as the hero figure with a detailed caption.

### 3. Section: "The Master Oscillator — Voltage-Controlled Crystal Oscillator (VCO/VCXO)"
Directly answer "what type of oscillator":
- All three manuals agree: the maser's master frequency reference is a **voltage-controlled crystal oscillator** — labeled "5 MHz VCO" in the MHM-2010 block diagram (housed inside the "Phase Detector & 5 MHz VCO" module) [MHM-2010 UG Fig.2], "VCO 5MHz" in the Vremya-CH PLL Unit [Vremya-CH OM §4.3, Fig.4], and explicitly termed a "voltage controlled crystal oscillator (VCXO)" in the NASA/IVS description of the NASA NR maser design [Diegel, "Principles of the Hydrogen Maser—Electronics," Phase Lock Loop section].
- This crystal oscillator is NOT free-running — it is phase-locked in a closed servo loop to the hydrogen hyperfine transition. The phase detector compares (a) the maser signal after it has been heterodyne-downconverted through the receiver chain to a low IF, against (b) a synthesizer-derived reference at the same nominal IF, and feeds a DC correction voltage back to the crystal oscillator's varactor to hold it in lock [Diegel; MHM-2010 UG Fig.2; Vremya-CH Fig.4].
- Note the MHM-2010's physical system layout confirms a discrete "5 MHz Crystal" module inside the electronics bay [MHM-2010 UG Fig.3].
- Table: compare the three designs' master oscillator + final IF/comparison frequency:
  | Design | Master oscillator | Final phase-detector comparison frequency |
  |---|---|---|
  | Microsemi/Microchip MHM-2010 | 5 MHz VCO | 5.751 kHz |
  | Vremya-CH VCH-1003M | 5 MHz VCO | 405.751 kHz |
  | NASA NR maser (Diegel/IVS generic description) | VCXO (freq. unspecified generically) | 5.751 kHz |

### 4. Section: "Where the Local Oscillators Come From"
Directly answer "where are the LOs generated":
- In the MHM-2010, the receiver's local oscillator is produced by the **"L.O. Multiplier"** block, which sits in the receive chain between the Receiver Amplifier and the I.F. Strip [MHM-2010 UG Fig.2]. Per the maser's own operating principle (Ch.I: "a phase-locked loop locks a voltage controlled crystal oscillator (VCO) to the maser output... Integral multipliers, dividers and buffer amplifiers... provide several isolated outputs"), this LO multiplier chain is referenced to the same 5 MHz VCO — i.e., the receiver's downconversion LO and the standard frequency outputs share one master crystal reference, multiplied to different destinations.
- The Vremya-CH design makes this explicit and quantified: its "Multiplier" block takes the 5 MHz VCO output and produces **two** multiplied outputs simultaneously — a 1400 MHz signal used as the **receiver local oscillator** (×280 from 5 MHz) and a 100 MHz standard output (×20 from 5 MHz) [Vremya-CH OM §4.3, Fig.4]. The 1400 MHz LO mixes with the 1420 MHz maser signal in the Heterodyne receiver to produce the 405.751 kHz IF used by the Phase Detector.
- The NASA/IVS generic description shows a **three-stage cascaded LO chain**, all derived from the same VCXO: 1.420405751 GHz mixed with a ~1.4 GHz LO1 → 20.405751 MHz; mixed with a 20 MHz LO2 → 405.751 kHz; mixed with a 400 kHz LO3 → 5.751 kHz final IF, sent to the phase detector [Diegel, Phase Lock Loop section: "As shown in Figure 5, all local oscillator signals are derived from the VCXO."]. This confirms the general architectural principle even though exact LO frequencies/stage counts differ between manufacturers.
- Embed a simple generated summary diagram (Mermaid or hand-built SVG in site style) showing this generic 3-stage cascade with labeled frequencies, credited as "redrawn from the architecture described in [Diegel, NASA/IVS]" — clearly marked as an editorial summary diagram, distinct from the manufacturer facsimiles above.

### 5. Section: "Where the 100 MHz Output Is Multiplied From"
Directly answer the other explicit question:
- Per MHM-2010 Chapter II spec: "The maser is available with various combinations of 5 MHz, 10 MHz, and 100 MHz signals with 1 volt RMS outputs resistively matched to 50Ω loads" [MHM-2010 UG Ch.II §A]. The block diagram shows the "Signal Buffers" stage taking the 5 MHz VCO output and producing a buffered/doubled 10 MHz output ("10 MHz to All Cct") plus 10 MHz feeds to the 14-digit Synthesizer and Cavity Register [MHM-2010 UG Fig.2]. The 100 MHz output is not itself drawn in this simplified block diagram but is produced by the same class of "integral multipliers, dividers and buffer amplifiers under temperature control" referenced in Ch.I — i.e., a further ×10 (from 10 MHz) or ×20 (from 5 MHz) multiplier/buffer stage from the identical master VCO reference.
- The Vremya-CH design documents this multiplication explicitly and numerically: 100 MHz = 5 MHz VCO × 20, generated in the same "Multiplier" module that also produces the 1400 MHz receiver LO (×280) [Vremya-CH OM §4.3, Fig.4, and §2.3 spec: "two 5 MHz, two 10 MHz, two 100 MHz sine signals... An additional output at 1400MHz... is available as an option"].
- Conclusion sentence: across manufacturers, the 100 MHz standard output and the microwave local oscillator(s) are not independent — they are both integer multiples of the same phase-locked master crystal oscillator, buffered and isolated (>100 dB isolation per NASA/IVS) so that no external load can pull the reference [Diegel, Signal Distribution section].

### 6. Section: "Cavity Auto-Tuning Loop" (brief, cross-reference — ties back to existing physics pages)
- Briefly describe the frequency-switching auto-tuner (MPG → Varactor Control → cavity tuning varactor; Synchronous Detector + Cavity Register close the loop) [MHM-2010 UG Fig.2; Vremya-CH §4.4 Fig.5]. Note this is a separate low-frequency (28.75 Hz / cavity-switching) servo from the main VCO phase-lock loop, and does not degrade short-term stability because it doesn't require beam-intensity switching [NRAO tutorial slide "Auto-Tuning"; MHM-2010 UG Ch.I "Auto-Tuning"].
- One-sentence link to the existing physics/disturbance-analysis page for readers who want the stability-impact side of this.

### 7. Section: Table — "Manual-documented output/LO frequencies at a glance"
| Signal | Frequency | Role | Source |
|---|---|---|---|
| Cavity/maser signal | 1,420,405,751.77 Hz | Hydrogen hyperfine transition, RF input to receiver | MHM-2010 UG Ch.II §J |
| Receiver LO (Vremya-CH) | 1400 MHz | Downconverts maser signal to 405.751 kHz IF | Vremya-CH OM Fig.4 |
| Receiver LO1 (NASA NR, generic) | ~1.4 GHz | First downconversion stage | Diegel |
| Master oscillator | 5 MHz | VCO/VCXO, phase-locked master reference | MHM-2010 UG Fig.2; Vremya-CH Fig.4 |
| Standard output | 10 MHz | Buffered ×2 from 5 MHz VCO | MHM-2010 UG Fig.2 |
| Standard output | 100 MHz | Buffered/multiplied (×20 from 5 MHz in Vremya-CH design) | Vremya-CH OM §4.3; MHM-2010 UG Ch.II §A |
| Final phase-detector IF (MHM-2010) | 5.751 kHz | Loop comparison frequency | MHM-2010 UG Ch.II §N |
| Final phase-detector IF (Vremya-CH) | 405.751 kHz | Loop comparison frequency | Vremya-CH OM §4.3 |

### 8. References to append to `references.html`
Add these (continue existing numbering):
- Microsemi/Microchip, "Atomic Hydrogen Maser MHM-2010 User's Guide, Rev J," 75666-201, Oct. 2014. [Online]. Available: https://www.gb.nrao.edu/~fghigo/timer/MSMmaser/Maser_UG_75666-201_Rev_J.PDF (NOTE: check if already reference [20] in the master list per prior research — if so, reuse that number, do not duplicate.)
- Vremya-CH JS Company, "VCH-1003M Active Hydrogen Maser Operations Manual," 411141.032 OM. [Online]. Available: http://www.heritek.com.cn/Private/Files/3505593a10526e3fabfc.pdf
- I. Diegel, "Hydrogen Maser Frequency Standard," Honeywell Technology Solutions, Inc., presented at NASA/IVS TOW 2013. [Online]. Available: https://ivscc.gsfc.nasa.gov/meetings/tow2013/Diegel.MW.pdf
- Microsemi, "Microwave Amplification by the Stimulated Emission of Radiation" (tutorial), 2016. [Online]. Available: https://www.gb.nrao.edu/~fghigo/timer/MSMmaser/Tutorial_short_072716.pdf
- NRAO, "VLBA Frequency and Time Standard," Observational Status Summary. [Online]. Available: https://science.nrao.edu/facilities/vlba/docs/manuals/oss2017b/sig-proc/freq-time

## Style/QA requirements
- Match existing page chrome exactly: same header/footer/nav partials, same CSS classes, same figure-caption component used on other pages (check `maser-physics-analysis.html` for the figure/caption pattern).
- All manual-facsimile images must be displayed at a size where labels are legible (min ~700px wide container, click-to-zoom/lightbox if the site already has that pattern from other pages — check hyperfine-structure.html/zeeman-splitting.html for existing image zoom component and reuse it).
- Every factual claim needs its inline citation matching the site's existing citation style.
- Add this page to the main nav on ALL other pages (not just itself) and to `index.html`'s tutorial hub links, consistent with how the other 6 tutorial pages are already linked everywhere.
- Include this page in Playwright QA pass (desktop 1280px+, mobile 375px, light+dark mode) before final deploy.

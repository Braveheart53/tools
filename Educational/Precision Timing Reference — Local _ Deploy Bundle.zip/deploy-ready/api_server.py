#!/usr/bin/env python3
"""Backend for the Timing project navigational site.

Serves file metadata (/api/files) and forces real downloads
(/download/<filename>) with a Content-Disposition: attachment header,
since the static-site proxy cannot force binary downloads on its own.
"""
from __future__ import annotations

import mimetypes
import os
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

BASE_DIR = Path(__file__).resolve().parent
DOWNLOAD_DIR = BASE_DIR / "downloads"

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# filename -> (display label, one-line description, category)
FILE_META = {
    "timing_project_full_bundle.zip": ("Full project bundle", "Every script, figure, and doc from this conversation in one zip.", "bundle"),
    "sa_stability_tool.zip": ("SA Stability Tool (zip)", "Complete Python 3.8/3.12 stability & phase-noise toolkit.", "bundle"),
    "README.md": ("SA Tool README", "Module docs, LaTeX equation appendix, IEEE reference table.", "docs"),
    "stability_core.py": ("stability_core.py", "ADEV / OADEV / MDEV / TDEV / OHDEV / Theo1 / ThêoBR / ThêoH estimators, drift removal, noise classification.", "sa_tool"),
    "phase_noise.py": ("phase_noise.py", "SSB phase noise via Welch PSD; frequency-domain noise classification; L(f)↔Sy(f) conversion.", "sa_tool"),
    "sa_convert.py": ("sa_convert.py", "Keysight / R&S / generic vendor spectrum-analyzer export → canonical CSV converter.", "sa_tool"),
    "stable32_export.py": ("stable32_export.py", "Stable32-compatible .PHD / .FRD / .DAT ASCII export.", "sa_tool"),
    "veusz_export.py": ("veusz_export.py", "Veusz .vszh5 export via isolated subprocess (avoids Qt binding conflicts).", "sa_tool"),
    "gui_app.py": ("gui_app.py", "PySide6 desktop GUI tying all modules together.", "sa_tool"),
    "requirements.txt": ("requirements.txt", "Dual Python 3.8 / 3.12 compatible dependency list.", "sa_tool"),
    "validate_core.py": ("validate_core.py", "Validation vs. allantools (0.0000% error).", "validation"),
    "validate_phase_noise.py": ("validate_phase_noise.py", "Validation of L(f) slope classification.", "validation"),
    "validate_sa_convert.py": ("validate_sa_convert.py", "Validation of vendor SA parsers.", "validation"),
    "validate_veusz_export.py": ("validate_veusz_export.py", "Validation of the Veusz export subprocess pipeline.", "validation"),
    "validate_gui.py": ("validate_gui.py", "Headless GUI smoke test.", "validation"),
    "physics_package_schematic.py": ("physics_package_schematic.py", "H-maser physics + electronics package architecture diagram (PLL-locked outputs).", "analysis"),
    "zeeman_curve.py": ("zeeman_curve.py", "Quadratic Zeeman shift of the 1420.405 MHz clock transition vs. C-field.", "analysis"),
    "disturbance_impact.py": ("disturbance_impact.py", "Fractional-frequency impact of local magnetic disturbances (Microchip / Safran).", "analysis"),
    "hvac_source.py": ("hvac_source.py", "Shared HVAC/VFD magnetic-disturbance source model (Karady et al. 1994).", "analysis"),
    "freq_shift_absolute.py": ("freq_shift_absolute.py", "Absolute (Hz) frequency shift from magnetic disturbances at 1.42 GHz / 10 MHz.", "analysis"),
    "freq_shift_vs_gps.py": ("freq_shift_vs_gps.py", "Equivalent 1PPS timing-drift slope vs. GPS from magnetic disturbances.", "analysis"),
    "thermal_pressure_slope.py": ("thermal_pressure_slope.py", "Equivalent 1PPS timing drift from temperature and barometric pressure.", "analysis"),
    "slope_change_detector.py": ("slope_change_detector.py", "Automated slope-change (F-step) detector: t-test + CUSUM, Chow (1960) / Page (1954).", "analysis"),
}

CODE_EXT = {".py", ".txt", ".md"}


@app.get("/api/files")
def list_files():
    out = []
    for fname, (label, desc, category) in FILE_META.items():
        fpath = DOWNLOAD_DIR / fname
        if not fpath.exists():
            continue
        out.append(
            {
                "filename": fname,
                "label": label,
                "description": desc,
                "category": category,
                "size_bytes": fpath.stat().st_size,
                "is_code": fpath.suffix in CODE_EXT,
            }
        )
    return out


@app.get("/api/source/{filename}")
def get_source(filename: str):
    """Return raw text content for in-page code viewing (not a download)."""
    fpath = (DOWNLOAD_DIR / filename).resolve()
    if DOWNLOAD_DIR.resolve() not in fpath.parents and fpath != DOWNLOAD_DIR.resolve():
        raise HTTPException(400, "invalid path")
    if not fpath.exists() or fpath.suffix not in CODE_EXT:
        raise HTTPException(404, "not found")
    return {"filename": filename, "content": fpath.read_text(encoding="utf-8", errors="replace")}


@app.get("/download/{filename}")
def download(filename: str):
    fpath = (DOWNLOAD_DIR / filename).resolve()
    if DOWNLOAD_DIR.resolve() not in fpath.parents and fpath != DOWNLOAD_DIR.resolve():
        raise HTTPException(400, "invalid path")
    if not fpath.exists() or not fpath.is_file():
        raise HTTPException(404, "not found")
    media_type = mimetypes.guess_type(str(fpath))[0] or "application/octet-stream"
    return FileResponse(
        path=str(fpath),
        media_type=media_type,
        filename=filename,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)

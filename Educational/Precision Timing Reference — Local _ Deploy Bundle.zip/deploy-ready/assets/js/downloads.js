/* downloads.js — wires pages/downloads.html to api_server.py when a backend
   is actually running (e.g. deploy_website's proxy, or api_server.py started
   alongside a self-hosted deployment), for real Content-Disposition-forced
   downloads. If no backend answers /api/files, this falls back to plain
   links straight at the files in this deployment's own downloads/ folder —
   no backend required for the site to work. */
(function () {
  var API = '__PORT_8000__'.indexOf('__') === 0 ? 'http://localhost:8000' : '__PORT_8000__';
  var DOWNLOAD_BASE = API + '/download/';
  var STATIC_BASE = '../downloads/';

  var CATEGORY_META = {
    bundle: { title: 'Full Bundles', order: 0 },
    analysis: { title: 'Analysis Scripts', order: 1 },
    sa_tool: { title: 'SA Stability Tool Modules', order: 2 },
    validation: { title: 'Validation Scripts', order: 3 },
    docs: { title: 'Documentation', order: 4 },
  };

  // Hardcoded fallback mirroring FILE_META in api_server.py, used only if
  // the live /api/files call fails, so the page never renders empty.
  var FALLBACK_FILES = [
    { filename: 'timing_project_full_bundle.zip', label: 'Full project bundle', description: 'Every script, figure, and doc from this conversation in one zip.', category: 'bundle', size_bytes: 1850122 },
    { filename: 'sa_stability_tool.zip', label: 'SA Stability Tool (zip)', description: 'Complete Python 3.8/3.12 stability & phase-noise toolkit.', category: 'bundle', size_bytes: 97529 },
    { filename: 'README.md', label: 'SA Tool README', description: 'Module docs, LaTeX equation appendix, IEEE reference table.', category: 'docs', size_bytes: 15952 },
    { filename: 'stability_core.py', label: 'stability_core.py', description: 'ADEV / OADEV / MDEV / TDEV / OHDEV / Theo1 / ThêoBR / ThêoH estimators, drift removal, noise classification.', category: 'sa_tool', size_bytes: 24456 },
    { filename: 'phase_noise.py', label: 'phase_noise.py', description: 'SSB phase noise via Welch PSD; frequency-domain noise classification; L(f)↔Sy(f) conversion.', category: 'sa_tool' },
    { filename: 'sa_convert.py', label: 'sa_convert.py', description: 'Keysight / R&S / generic vendor spectrum-analyzer export → canonical CSV converter.', category: 'sa_tool' },
    { filename: 'stable32_export.py', label: 'stable32_export.py', description: 'Stable32-compatible .PHD / .FRD / .DAT ASCII export.', category: 'sa_tool' },
    { filename: 'veusz_export.py', label: 'veusz_export.py', description: 'Veusz .vszh5 export via isolated subprocess (avoids Qt binding conflicts).', category: 'sa_tool' },
    { filename: 'gui_app.py', label: 'gui_app.py', description: 'PySide6 desktop GUI tying all modules together.', category: 'sa_tool' },
    { filename: 'requirements.txt', label: 'requirements.txt', description: 'Dual Python 3.8 / 3.12 compatible dependency list.', category: 'sa_tool' },
    { filename: 'validate_core.py', label: 'validate_core.py', description: 'Validation vs. allantools (0.0000% error).', category: 'validation' },
    { filename: 'validate_phase_noise.py', label: 'validate_phase_noise.py', description: 'Validation of L(f) slope classification.', category: 'validation' },
    { filename: 'validate_sa_convert.py', label: 'validate_sa_convert.py', description: 'Validation of vendor SA parsers.', category: 'validation' },
    { filename: 'validate_veusz_export.py', label: 'validate_veusz_export.py', description: 'Validation of the Veusz export subprocess pipeline.', category: 'validation' },
    { filename: 'validate_gui.py', label: 'validate_gui.py', description: 'Headless GUI smoke test.', category: 'validation' },
    { filename: 'physics_package_schematic.py', label: 'physics_package_schematic.py', description: 'H-maser physics + electronics package architecture diagram (PLL-locked outputs).', category: 'analysis' },
    { filename: 'zeeman_curve.py', label: 'zeeman_curve.py', description: 'Quadratic Zeeman shift of the 1420.405 MHz clock transition vs. C-field.', category: 'analysis' },
    { filename: 'disturbance_impact.py', label: 'disturbance_impact.py', description: 'Fractional-frequency impact of local magnetic disturbances (Microchip / Safran).', category: 'analysis' },
    { filename: 'hvac_source.py', label: 'hvac_source.py', description: 'Shared HVAC/VFD magnetic-disturbance source model (Karady et al. 1994).', category: 'analysis' },
    { filename: 'freq_shift_absolute.py', label: 'freq_shift_absolute.py', description: 'Absolute (Hz) frequency shift from magnetic disturbances at 1.42 GHz / 10 MHz.', category: 'analysis' },
    { filename: 'freq_shift_vs_gps.py', label: 'freq_shift_vs_gps.py', description: 'Equivalent 1PPS timing-drift slope vs. GPS from magnetic disturbances.', category: 'analysis' },
    { filename: 'thermal_pressure_slope.py', label: 'thermal_pressure_slope.py', description: 'Equivalent 1PPS timing drift from temperature and barometric pressure.', category: 'analysis' },
    { filename: 'slope_change_detector.py', label: 'slope_change_detector.py', description: 'Automated slope-change (F-step) detector: t-test + CUSUM, Chow (1960) / Page (1954).', category: 'analysis' },
  ];

  function fmtSize(bytes) {
    if (!bytes) return '';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  function render(files, viaApi) {
    var base = viaApi ? DOWNLOAD_BASE : STATIC_BASE;
    var statusEl = document.getElementById('dl-status');
    statusEl.textContent = viaApi
      ? 'Live file list loaded from /api/files \u2014 ' + files.length + ' files.'
      : 'No backend detected \u2014 linking directly to the ' + files.length + ' files in this site\u2019s downloads/ folder.';
    statusEl.setAttribute('data-state', viaApi ? 'ok' : 'ok');

    var bundleSlot = document.getElementById('dl-bundle-slot');
    var groupsEl = document.getElementById('dl-groups');
    groupsEl.innerHTML = '';
    bundleSlot.innerHTML = '';

    var byCategory = {};
    files.forEach(function (f) {
      if (!byCategory[f.category]) byCategory[f.category] = [];
      byCategory[f.category].push(f);
    });

    // "Download Everything" bundle card at top
    var fullBundle = files.find(function (f) { return f.filename === 'timing_project_full_bundle.zip'; });
    if (fullBundle) {
      bundleSlot.innerHTML =
        '<div class="bundle-card">' +
        '<div><h3>Download Everything</h3><p style="margin:0;font-size:var(--text-sm);color:var(--color-text-muted);">' +
        fullBundle.description + ' (' + fmtSize(fullBundle.size_bytes) + ')</p></div>' +
        '<a class="btn btn--primary" href="' + base + encodeURIComponent(fullBundle.filename) + '" download>' +
        'Download bundle</a>' +
        '</div>';
    }

    var order = ['bundle', 'analysis', 'sa_tool', 'validation', 'docs'];
    order.forEach(function (cat) {
      var items = byCategory[cat];
      if (!items || !items.length) return;
      // skip the full bundle in its own list section (already shown above), but keep sa_stability_tool.zip
      items = items.filter(function (f) { return f.filename !== 'timing_project_full_bundle.zip'; });
      if (!items.length) return;
      var meta = CATEGORY_META[cat] || { title: cat };
      var html = '<p class="card-grid--section-title" style="margin-top:var(--space-12);">' + meta.title + '</p>';
      items.forEach(function (f) {
        html +=
          '<div class="download-item">' +
          '<div class="download-item__meta">' +
          '<span class="download-item__name">' + f.label + '</span>' +
          '<span class="download-item__desc">' + f.description + '</span>' +
          (f.size_bytes ? '<span class="download-item__size">' + fmtSize(f.size_bytes) + '</span>' : '') +
          '</div>' +
          '<a class="btn btn--outline" href="' + base + encodeURIComponent(f.filename) + '" download>Download</a>' +
          '</div>';
      });
      groupsEl.innerHTML += html;
    });
  }

  fetch(API + '/api/files')
    .then(function (res) {
      if (!res.ok) throw new Error('bad status ' + res.status);
      return res.json();
    })
    .then(function (files) {
      if (!Array.isArray(files) || !files.length) throw new Error('empty file list');
      render(files, true);
    })
    .catch(function () {
      render(FALLBACK_FILES, false);
    });
})();

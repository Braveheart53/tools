/* hyperfine-animation.js — schematic energy-level splitting animation
   for pages/hyperfine-structure.html. Arbitrary field units; qualitative
   fan-out (linear m_F=+-1) + quadratic bend (m_F=0 mixing), matching the
   fig3_zeeman_curve.png color conventions (blue/orange/green/purple). */
(function () {
  var canvas = document.getElementById('hyperfine-canvas');
  if (!canvas) return;
  var ctx = canvas.getContext('2d');
  var slider = document.getElementById('hf-field');
  var readout = document.getElementById('hf-readout');
  var playBtn = document.getElementById('hf-play');

  var W = canvas.width, H = canvas.height;
  var playing = false, playDir = 1, rafId = null;

  function colors() {
    var cs = getComputedStyle(document.documentElement);
    return {
      text: cs.getPropertyValue('--color-text-muted').trim() || '#4d5768',
      grid: cs.getPropertyValue('--color-divider').trim() || '#ddd5c0',
      blue: cs.getPropertyValue('--color-primary').trim() || '#2b6cb0',
      amber: cs.getPropertyValue('--color-warning').trim() || '#dd6b20',
      green: cs.getPropertyValue('--color-success').trim() || '#38a169',
      purple: cs.getPropertyValue('--color-purple').trim() || '#805ad5',
    };
  }

  function draw(b) {
    var c = colors();
    ctx.clearRect(0, 0, W, H);

    var padL = 90, padR = 40, padT = 30, padB = 50;
    var plotW = W - padL - padR, plotH = H - padT - padB;
    // Energy range spans from +A (top, plus headroom for the linear fan-out
    // at max field) down to -3A (bottom, plus headroom for the small
    // quadratic upward bend) -- roughly 4.6 units of A total; scale so the
    // full range fits inside plotH with margin.
    var scaleE = plotH / 4.6; // energy pixel scale (A = 1 unit)
    var yMid = padT + scaleE * 1.15; // puts E=+A near the top with headroom

    function toY(E) { return yMid - E * scaleE; }
    function toX(bb) { return padL + (bb / 100) * plotW; }

    // axes
    ctx.strokeStyle = c.grid;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padL, padT); ctx.lineTo(padL, H - padB); ctx.lineTo(W - padR, H - padB);
    ctx.stroke();
    ctx.fillStyle = c.text;
    ctx.font = '12px var(--font-mono), monospace';
    ctx.textAlign = 'center';
    ctx.fillText('External field, B (arbitrary units) \u2192', (padL + W - padR) / 2, H - 14);
    ctx.save();
    ctx.translate(24, (padT + H - padB) / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText('Energy (units of A)', 0, 0);
    ctx.restore();

    // curves across full b range, sampled
    var mu = 1.0, muPrime = 1.0, A = 1.0;
    function EI(bb) { return A + mu * (bb / 100); }
    function EII_(bb) { return A - mu * (bb / 100); }
    function EIII(bb) { var x = (bb / 100); return A * (-1 + 2 * Math.sqrt(1 + (muPrime * muPrime * x * x) / (4 * A * A))); }
    function EIV(bb) { var x = (bb / 100); return -A * (1 + 2 * Math.sqrt(1 + (muPrime * muPrime * x * x) / (4 * A * A))); }

    function plotCurve(fn, color, dashed) {
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = 2.5;
      if (dashed) ctx.setLineDash([5, 4]); else ctx.setLineDash([]);
      for (var bb = 0; bb <= 100; bb += 1) {
        var x = toX(bb), y = toY(fn(bb));
        if (bb === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // full faint traces
    ctx.globalAlpha = 0.28;
    plotCurve(EI, c.blue);
    plotCurve(EII_, c.amber);
    plotCurve(EIII, c.green);
    plotCurve(EIV, c.purple);
    ctx.globalAlpha = 1;

    // solid up to current b
    function plotUpTo(fn, color, bmax) {
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      for (var bb = 0; bb <= bmax; bb += 1) {
        var x = toX(bb), y = toY(fn(bb));
        if (bb === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
      // dot at current position
      var xEnd = toX(bmax), yEnd = toY(fn(bmax));
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.arc(xEnd, yEnd, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }
    plotUpTo(EI, c.blue, b);
    plotUpTo(EII_, c.amber, b);
    plotUpTo(EIII, c.green, b);
    plotUpTo(EIV, c.purple, b);

    // Labels placed at b=35 (where the linear/quadratic branches have
    // visibly separated) rather than b=0 (where EI=EII and EIII=EIV
    // coincide at B=0, which caused overlapping text).
    var lb = 35;
    ctx.font = '11px var(--font-mono), monospace';
    ctx.textAlign = 'left';
    ctx.fillStyle = c.blue;
    ctx.fillText('F=1, m\u2091=+1', toX(lb) + 8, toY(EI(lb)) - 6);
    ctx.fillStyle = c.amber;
    ctx.fillText('F=1, m\u2091=\u22121', toX(lb) + 8, toY(EII_(lb)) + 16);
    ctx.fillStyle = c.green;
    ctx.fillText('F=1, m\u2091=0 (mix)', toX(lb) + 8, toY(EIII(lb)) - 6);
    ctx.fillStyle = c.purple;
    ctx.fillText('F=0, m\u2091=0 (mix)', toX(lb) + 8, toY(EIV(lb)) + 16);
  }

  function update() {
    var b = parseFloat(slider.value);
    readout.textContent = 'B = ' + b.toFixed(0) + ' (arb. units)';
    draw(b);
  }

  slider.addEventListener('input', update);
  window.addEventListener('resize', update);

  playBtn.addEventListener('click', function () {
    playing = !playing;
    playBtn.textContent = playing ? 'Pause \u23f8' : 'Auto-play \u25b6';
    if (playing) animate();
  });

  function animate() {
    if (!playing) return;
    var v = parseFloat(slider.value);
    v += playDir * 1.2;
    if (v >= 100) { v = 100; playDir = -1; }
    if (v <= 0) { v = 0; playDir = 1; }
    slider.value = v;
    update();
    rafId = requestAnimationFrame(function () {
      setTimeout(animate, 20);
    });
  }

  update();

  // Respect reduced motion: disable autoplay affordance visually if requested
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    playBtn.disabled = true;
    playBtn.title = 'Autoplay disabled (reduced motion preference)';
    playBtn.style.opacity = '0.5';
  }
})();

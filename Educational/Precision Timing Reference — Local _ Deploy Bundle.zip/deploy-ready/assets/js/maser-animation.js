/* maser-animation.js — schematic population-inversion / photon-cascade
   animation for pages/what-is-a-maser.html. 2-3 inverted atoms in a cavity;
   an incident photon triggers stimulated emission of an in-phase photon
   from each atom it passes, growing the coherent photon count. */
(function () {
  var canvas = document.getElementById('maser-canvas');
  if (!canvas) return;
  var ctx = canvas.getContext('2d');
  var playBtn = document.getElementById('maser-play');
  var resetBtn = document.getElementById('maser-reset');
  var readout = document.getElementById('maser-readout');

  var W = canvas.width, H = canvas.height;
  var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Atom positions inside the cavity (upper-state = excited, ground = de-excited after emission)
  var atoms = [
    { x: 260, y: 130, excited: true },
    { x: 500, y: 260, excited: true },
    { x: 700, y: 150, excited: true },
  ];

  // Photon list: {x,y,vx,vy,phase} - phase used to draw in-phase coherent wave color
  var photons = [];
  var coherentCount = 1;
  var playing = false;
  var rafId = null;
  var t = 0;

  function colors() {
    var cs = getComputedStyle(document.documentElement);
    return {
      text: cs.getPropertyValue('--color-text-muted').trim() || '#4d5768',
      border: cs.getPropertyValue('--color-border').trim() || '#cdc3a6',
      blue: cs.getPropertyValue('--color-primary').trim() || '#2b6cb0',
      amber: cs.getPropertyValue('--color-warning').trim() || '#dd6b20',
      green: cs.getPropertyValue('--color-success').trim() || '#38a169',
      surface: cs.getPropertyValue('--color-surface').trim() || '#fbf9f2',
    };
  }

  function resetState() {
    atoms.forEach(function (a) { a.excited = true; });
    photons = [{ x: 40, y: 200, vx: 4.2, vy: 0 }];
    coherentCount = 1;
    t = 0;
    readout.textContent = 'Coherent photons: 1';
    draw();
  }

  function drawCavity(c) {
    ctx.strokeStyle = c.border;
    ctx.lineWidth = 2;
    ctx.strokeRect(20, 40, W - 40, H - 90);
    ctx.font = '11px var(--font-mono), monospace';
    ctx.fillStyle = c.text;
    ctx.fillText('Resonant cavity (schematic)', 30, 30);
  }

  function drawAtom(a, c) {
    ctx.beginPath();
    ctx.arc(a.x, a.y, 22, 0, Math.PI * 2);
    ctx.fillStyle = a.excited ? c.amber : c.blue;
    ctx.globalAlpha = a.excited ? 0.85 : 0.35;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = c.text;
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.font = '10px var(--font-mono), monospace';
    ctx.textAlign = 'center';
    ctx.fillText(a.excited ? 'F=1\nm=0' : 'F=0\nm=0', a.x, a.y + 4);
  }

  function drawAtomLabel(a, c) {
    ctx.fillStyle = c.text;
    ctx.font = '10px var(--font-mono), monospace';
    ctx.textAlign = 'center';
    ctx.fillText(a.excited ? 'excited' : 'ground', a.x, a.y + 40);
  }

  function drawPhoton(p, c) {
    // draw as a small wavy packet
    ctx.strokeStyle = c.green;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    var len = 26;
    for (var i = -len; i <= len; i += 2) {
      var yy = p.y + Math.sin((i + t * 6) * 0.5) * 5;
      var xx = p.x + i;
      if (i === -len) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
    }
    ctx.stroke();
    // arrowhead
    ctx.beginPath();
    ctx.fillStyle = c.green;
    ctx.moveTo(p.x + len, p.y);
    ctx.lineTo(p.x + len - 8, p.y - 5);
    ctx.lineTo(p.x + len - 8, p.y + 5);
    ctx.fill();
  }

  function draw() {
    var c = colors();
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = c.surface;
    ctx.fillRect(0, 0, W, H);
    drawCavity(c);
    atoms.forEach(function (a) { drawAtom(a, c); drawAtomLabel(a, c); });
    photons.forEach(function (p) { drawPhoton(p, c); });

    ctx.fillStyle = c.text;
    ctx.font = '11px var(--font-mono), monospace';
    ctx.textAlign = 'left';
    ctx.fillText('Incident + stimulated photons travel left \u2192 right, in phase', 30, H - 20);
  }

  function step() {
    t += 1;
    var c = colors();
    photons.forEach(function (p) { p.x += p.vx; });

    // check collisions with excited atoms
    atoms.forEach(function (a) {
      if (!a.excited) return;
      photons.forEach(function (p) {
        if (Math.abs(p.x - a.x) < 22) {
          a.excited = false;
          coherentCount += 1;
          // emit a new in-phase photon slightly offset in y, continuing rightward
          photons.push({ x: a.x + 20, y: a.y + (photons.length % 2 === 0 ? 8 : -8), vx: 4.2, vy: 0 });
          readout.textContent = 'Coherent photons: ' + coherentCount;
        }
      });
    });

    // remove photons that exit cavity
    photons = photons.filter(function (p) { return p.x < W - 10; });

    draw();

    var allDone = atoms.every(function (a) { return !a.excited; }) && photons.length > 0 && photons.every(function (p) { return p.x > W - 60; });
    if (allDone) {
      playing = false;
      playBtn.textContent = 'Play cascade \u25b6';
      return;
    }
    if (playing) {
      rafId = requestAnimationFrame(function () { setTimeout(step, reducedMotion ? 0 : 16); });
    }
  }

  playBtn.addEventListener('click', function () {
    if (photons.length === 0) resetState();
    playing = !playing;
    playBtn.textContent = playing ? 'Pause \u23f8' : 'Play cascade \u25b6';
    if (playing) step();
  });

  resetBtn.addEventListener('click', function () {
    playing = false;
    playBtn.textContent = 'Play cascade \u25b6';
    if (rafId) cancelAnimationFrame(rafId);
    resetState();
  });

  resetState();
})();

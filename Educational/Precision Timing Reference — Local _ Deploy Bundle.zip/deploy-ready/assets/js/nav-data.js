/* nav-data.js — single source of truth for site navigation.
   Loaded before partials.js on every page. Paths are relative to site root. */
window.SITE_NAV = {
  brandHref: '__ROOT__/index.html',
  groups: [
    {
      label: 'Tutorial',
      items: [
        { href: '__ROOT__/pages/hyperfine-structure.html', title: 'Hyperfine Structure' },
        { href: '__ROOT__/pages/zeeman-splitting.html', title: 'Zeeman Splitting' },
        { href: '__ROOT__/pages/what-is-a-maser.html', title: 'What Is a Maser?' },
        { href: '__ROOT__/pages/electronics-package.html', title: 'Electronics Package' },
      ],
    },
    {
      label: 'Tools & Analysis',
      items: [
        { href: '__ROOT__/pages/maser-physics-analysis.html', title: 'Disturbance & Frequency-Shift Analysis' },
        { href: '__ROOT__/pages/sa-stability-tool.html', title: 'SA Stability & Phase-Noise Tool' },
      ],
    },
    {
      label: 'Reference',
      items: [
        { href: '__ROOT__/pages/references.html', title: 'References (IEEE Format)' },
        { href: '__ROOT__/pages/unit-conversion.html', title: 'Unit Conversion (CGS \u2192 SI)' },
        { href: '__ROOT__/pages/downloads.html', title: 'Downloads' },
      ],
    },
  ],
};

/* Tutorial sequence order, used for Prev/Next footer nav on tutorial-sequence pages */
window.SITE_SEQUENCE = [
  { href: '__ROOT__/pages/hyperfine-structure.html', title: 'Hyperfine Structure of Atomic Hydrogen' },
  { href: '__ROOT__/pages/zeeman-splitting.html', title: 'The Zeeman Effect in the Clock Transition' },
  { href: '__ROOT__/pages/what-is-a-maser.html', title: 'What Is Masing? Maser vs. Laser' },
  { href: '__ROOT__/pages/electronics-package.html', title: 'Inside the Maser: Receiver, PLL & Frequency Chain' },
  { href: '__ROOT__/pages/maser-physics-analysis.html', title: 'Environmental Disturbances & Frequency-Shift Analysis' },
  { href: '__ROOT__/pages/sa-stability-tool.html', title: 'SA Stability & Phase-Noise Analysis Tool' },
];

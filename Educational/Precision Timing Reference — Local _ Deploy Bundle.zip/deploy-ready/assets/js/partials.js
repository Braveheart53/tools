/* partials.js — builds header/footer/theme-toggle/mobile-nav at runtime.
   Documented choice (see BRIEF.md "Site Architecture"): runtime JS partial
   injection was chosen over a build-script template assembler because this
   project has no Node/build pipeline in its deploy path (plain static HTML
   served via deploy_website) and a small inline script keeps every page
   self-consistent without a separate build step to remember to re-run. */
(function () {
  var ROOT = document.documentElement.getAttribute('data-root') || '.';
  var CURRENT = document.documentElement.getAttribute('data-page') || '';

  function resolve(href) {
    return href.replace('__ROOT__', ROOT);
  }

  function buildLogo() {
    return (
      '<svg width="26" height="26" viewBox="0 0 32 32" fill="none" aria-hidden="true">' +
      '<circle cx="16" cy="16" r="14.5" stroke="currentColor" stroke-width="1.5"/>' +
      '<circle cx="16" cy="16" r="2.4" fill="currentColor"/>' +
      '<path d="M16 16 L16 4" stroke="currentColor" stroke-width="1.5"/>' +
      '<path d="M16 16 L25 21" stroke="currentColor" stroke-width="1.5"/>' +
      '<circle cx="16" cy="4" r="1.6" fill="currentColor"/>' +
      '<circle cx="25" cy="21" r="1.6" fill="currentColor"/>' +
      '</svg>'
    );
  }

  function buildHeader() {
    var nav = window.SITE_NAV;
    var groupsHtml = nav.groups
      .map(function (g) {
        var itemsHtml = g.items
          .map(function (it) {
            var href = resolve(it.href);
            var current = CURRENT === it.href ? ' aria-current="page"' : '';
            return '<a href="' + href + '"' + current + '>' + it.title + '</a>';
          })
          .join('');
        return (
          '<div class="nav-group">' +
          '<button type="button" class="nav-group__label" aria-expanded="false">' +
          g.label +
          ' <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>' +
          '</button>' +
          '<div class="nav-group__menu" role="menu">' +
          itemsHtml +
          '</div>' +
          '</div>'
        );
      })
      .join('');

    var header = document.createElement('header');
    header.className = 'site-header';
    header.innerHTML =
      '<div class="container site-header__bar">' +
      '<a class="brand" href="' +
      resolve(nav.brandHref) +
      '">' +
      buildLogo() +
      '<span>PRECISION&nbsp;TIMING&nbsp;REF</span>' +
      '</a>' +
      '<nav class="main-nav" id="main-nav" aria-label="Primary">' +
      groupsHtml +
      '</nav>' +
      '<div class="header-actions">' +
      '<button type="button" class="theme-toggle" data-theme-toggle aria-label="Switch to dark mode">' +
      '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>' +
      '</button>' +
      '<button type="button" class="nav-toggle" id="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">' +
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 6h18M3 12h18M3 18h18"/></svg>' +
      '</button>' +
      '</div>' +
      '</div>';

    document.getElementById('site-header').replaceWith(header);

    // Mobile nav toggle
    var navToggle = document.getElementById('nav-toggle');
    var mainNav = document.getElementById('main-nav');
    navToggle.addEventListener('click', function () {
      var open = mainNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(open));
    });
    // Mobile accordion for nav groups
    header.querySelectorAll('.nav-group__label').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        if (window.innerWidth > 860) return;
        var group = btn.closest('.nav-group');
        group.classList.toggle('is-expanded');
      });
    });
  }

  function buildFooter() {
    var nav = window.SITE_NAV;
    var colsHtml = nav.groups
      .map(function (g) {
        var itemsHtml = g.items
          .map(function (it) {
            return '<a href="' + resolve(it.href) + '">' + it.title + '</a>';
          })
          .join('');
        return '<div class="footer-col"><h4>' + g.label + '</h4>' + itemsHtml + '</div>';
      })
      .join('');

    var footer = document.createElement('footer');
    footer.className = 'site-footer';
    footer.innerHTML =
      '<div class="container">' +
      colsHtml +
      '<div class="footer-col"><h4>About</h4>' +
      '<p class="footer-note">A reference and tutorial on hydrogen maser physics and the ' +
      'frequency-stability analysis tools used to characterize precision oscillators. ' +
      'Every claim links to a numbered source on the <a href="' +
      resolve('__ROOT__/pages/references.html') +
      '" style="display:inline;color:var(--color-primary)">References</a> page.</p>' +
      '</div>' +
      '</div>';
    document.getElementById('site-footer').replaceWith(footer);
  }

  function initThemeToggle() {
    var t = document.querySelector('[data-theme-toggle]');
    var r = document.documentElement;
    var d = matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light';
    r.setAttribute('data-theme', d);
    updateToggleIcon(t, d);
    t.addEventListener('click', function () {
      d = d === 'dark' ? 'light' : 'dark';
      r.setAttribute('data-theme', d);
      updateToggleIcon(t, d);
    });
  }

  function updateToggleIcon(t, d) {
    t.setAttribute('aria-label', 'Switch to ' + (d === 'dark' ? 'light' : 'dark') + ' mode');
    t.innerHTML =
      d === 'dark'
        ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>'
        : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
  }

  function buildSequenceNav() {
    var el = document.getElementById('sequence-nav');
    if (!el) return;
    var seq = window.SITE_SEQUENCE;
    var idx = seq.findIndex(function (s) {
      return s.href === CURRENT;
    });
    if (idx === -1) {
      el.remove();
      return;
    }
    var prev = idx > 0 ? seq[idx - 1] : null;
    var next = idx < seq.length - 1 ? seq[idx + 1] : null;
    var html = '';
    if (prev) {
      html +=
        '<a class="sequence-nav__link sequence-nav__link--prev" href="' +
        resolve(prev.href) +
        '"><span class="sequence-nav__dir">&larr; Previous</span><span class="sequence-nav__title">' +
        prev.title +
        '</span></a>';
    } else {
      html += '<span></span>';
    }
    if (next) {
      html +=
        '<a class="sequence-nav__link sequence-nav__link--next" href="' +
        resolve(next.href) +
        '"><span class="sequence-nav__dir">Next &rarr;</span><span class="sequence-nav__title">' +
        next.title +
        '</span></a>';
    }
    el.innerHTML = html;
  }

  document.addEventListener('DOMContentLoaded', function () {
    buildHeader();
    buildFooter();
    initThemeToggle();
    buildSequenceNav();
  });
})();

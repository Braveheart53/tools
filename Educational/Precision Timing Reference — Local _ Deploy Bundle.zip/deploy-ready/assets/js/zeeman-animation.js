/* zeeman-animation.js — interactive quadratic Zeeman-shift plot for
   pages/zeeman-splitting.html. Delta-nu = K_B * B^2.
   K_B = 2750 Hz/Gauss^2 = 2.750e11 Hz/Tesla^2 (matches downloads/zeeman_curve.py
   exactly -- that script's docstring notes an EARLIER DRAFT used an
   incorrectly-scaled K_B that was 10x too small; this uses the corrected
   value and the same mG -> T conversion: B_T = B_mG * 1e-3 * 1e-4). */
(function () {
  var canvas = document.getElementById('zeeman-canvas');
  if (!canvas) return;
  var ctx = canvas.getContext('2d');
  var slider = document.getElementById('zm-field');
  var readout = document.getElementById('zm-readout');

  var K_B = 2.750e11; // Hz / Tesla^2  (= 2750 Hz/Gauss^2)
  var W = canvas.width, H = canvas.height;
  var maxMG = 5; // slider max, milligauss -- matches zeeman_curve.py's realistic 0-5 mG maser operating range

  function colors() {
    var cs = getComputedStyle(document.documentElement);
    return {
      text: cs.getPropertyValue('--color-text-muted').trim() || '#4d5768',
      grid: cs.getPropertyValue('--color-divider').trim() || '#ddd5c0',
      blue: cs.getPropertyValue('--color-primary').trim() || '#2b6cb0',
      amber: cs.getPropertyValue('--color-warning').trim() || '#dd6b20',
    };
  }

  function deltaNu(mG) {
    var bT = mG * 1e-3 * 1e-4; // mG -> G -> T (identical conversion to zeeman_curve.py)
    return K_B * bT * bT; // Hz
  }

  function draw(currentMG) {
    var c = colors();
    ctx.clearRect(0, 0, W, H);
    var padL = 90, padR = 30, padT = 30, padB = 50;
    var plotW = W - padL - padR, plotH = H - padT - padB;
    var maxDeltaNu = deltaNu(maxMG);

    function toX(mg) { return padL + (mg / maxMG) * plotW; }
    function toY(dn) { return padT + plotH - (dn / maxDeltaNu) * plotH; }

    // axes
    ctx.strokeStyle = c.grid;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padL, padT); ctx.lineTo(padL, H - padB); ctx.lineTo(W - padR, H - padB);
    ctx.stroke();

    // gridlines + tick labels (x)
    ctx.fillStyle = c.text;
    ctx.font = '11px var(--font-mono), monospace';
    ctx.textAlign = 'center';
    var tickStep = maxMG / 5;
    for (var mg = 0; mg <= maxMG; mg += tickStep) {
      var x = toX(mg);
      ctx.strokeStyle = c.grid;
      ctx.beginPath(); ctx.moveTo(x, padT); ctx.lineTo(x, H - padB); ctx.stroke();
      ctx.fillText(mg.toFixed(1), x, H - padB + 18);
    }
    ctx.fillText('Internal C-field, H (mG) \u2192', (padL + W - padR) / 2, H - 12);

    ctx.save();
    ctx.translate(22, (padT + H - padB) / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = 'center';
    ctx.fillText('Quadratic Zeeman shift \u0394\u03bd (Hz)', 0, 0);
    ctx.restore();

    // curve
    ctx.beginPath();
    ctx.strokeStyle = c.blue;
    ctx.lineWidth = 3;
    for (var i = 0; i <= 200; i++) {
      var mgv = (i / 200) * maxMG;
      var x2 = toX(mgv), y2 = toY(deltaNu(mgv));
      if (i === 0) ctx.moveTo(x2, y2); else ctx.lineTo(x2, y2);
    }
    ctx.stroke();

    // current point + guide lines
    var curDn = deltaNu(currentMG);
    var cx = toX(currentMG), cy = toY(curDn);
    ctx.strokeStyle = c.amber;
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(cx, H - padB); ctx.lineTo(cx, cy); ctx.lineTo(padL, cy); ctx.stroke();
    ctx.setLineDash([]);

    ctx.beginPath();
    ctx.fillStyle = c.amber;
    ctx.arc(cx, cy, 6, 0, Math.PI * 2);
    ctx.fill();
  }

  function update() {
    var mg = parseFloat(slider.value);
    var dn = deltaNu(mg);
    readout.textContent = 'H = ' + mg.toFixed(2) + ' mG \u2192 \u0394\u03bd = ' + dn.toFixed(6) + ' Hz';
    draw(mg);
  }

  slider.addEventListener('input', update);
  window.addEventListener('resize', update);
  update();
})();

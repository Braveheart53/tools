"""
Estimated fractional-frequency impact of common local magnetic-field
disturbance sources on the Microchip MHM/MSM-2010 and Safran (T4Science)
iMaser 3000 active hydrogen masers.

Python 3.12
Author: Perplexity Computer / Timing project
Sources: see reference table in accompanying report.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from hvac_source import build_hvac_entries, HVAC_SOURCE_NOTE

# ---------------------------------------------------------------------------
# 1. Manufacturer-specified magnetic sensitivity coefficients (fractional
#    frequency change per Gauss of *external* ambient field change).
#    These already include the effect of the internal magnetic shielding.
# ---------------------------------------------------------------------------
sensitivity = {
    "Microchip MHM/MSM-2010\n(<3e-14/G = <3e-10/T, Rev J UG)": 3.0e-14,
    "Safran iMaser 3000\nStandard (<5e-14/G = <5e-10/T)": 5.0e-14,
    "Safran iMaser 3000\nMS option (<1e-14/G = <1e-10/T)": 1.0e-14,
}

# ---------------------------------------------------------------------------
# 2. Representative ambient magnetic-field disturbance magnitudes (Gauss),
#    drawn from the literature (see report reference table for citations).
#    Values are order-of-magnitude, midpoint of the cited range.
# ---------------------------------------------------------------------------
hvac_entries_G, hvac_brackets_G, hvac_labels_by_distance = build_hvac_entries()
HVAC_KEYS = list(hvac_labels_by_distance.values())  # ordered far -> near (25, 10, 3, 1 m)

disturbances_G = {
    **hvac_entries_G,
    "Quiet geomagnetic diurnal\nvariation (0.0002-0.0005 G\n= 20-50 nT)": 3.5e-4,
    "Moderate geomagnetic\nstorm, G2 (0.0005-0.001 G\n= 50-100 nT)": 7.5e-4,
    "Extreme geomagnetic\nstorm, G5 (>0.0025 G\n= >250 nT)": 3.0e-3,
    "Stationary-site ambient\n(elevators/motors, 0.01-0.02 G\n= 1-2 uT)": 1.5e-2,
    "Nearby moving mass\n(vehicle, dish drive, ~1 G\n= 100 uT = 1e-4 T)": 1.0,
    "Unshielded local transient\nevent (0.01 G = 1 uT = 1000 nT)\n[Kashima VLBI 1984]": 1.0e-2,
}

# ---------------------------------------------------------------------------
# 3. Compute Delta f / f = sensitivity_coeff * delta_B  for every combination
# ---------------------------------------------------------------------------
sources = list(disturbances_G.keys())
masers = list(sensitivity.keys())

data = np.zeros((len(sources), len(masers)))
for i, s in enumerate(sources):
    for j, m in enumerate(masers):
        data[i, j] = disturbances_G[s] * sensitivity[m]

# ---------------------------------------------------------------------------
# 4. Plot: grouped horizontal bar chart, log x-axis
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(11, 10.5))
y = np.arange(len(sources))
bar_h = 0.25
colors = ["#2b6cb0", "#dd6b20", "#38a169"]

for j, m in enumerate(masers):
    ax.barh(y + (j - 1) * bar_h, data[:, j], height=bar_h, label=m, color=colors[j])

# Overlay explicit max/min/mean error bars on every HVAC distance row, since
# reputable sources disagree by orders of magnitude on the near-field value
# used for extrapolation (see hvac_source.py note above).
for hvac_key in HVAC_KEYS:
    hvac_i = sources.index(hvac_key)
    bracket = hvac_brackets_G[hvac_key]
    for j, m in enumerate(masers):
        mean_val = bracket["mean"] * sensitivity[m]
        lo_val = bracket["min"] * sensitivity[m]
        hi_val = bracket["max"] * sensitivity[m]
        ax.errorbar(
            mean_val, hvac_i + (j - 1) * bar_h,
            xerr=[[mean_val - lo_val], [hi_val - mean_val]],
            fmt="none", ecolor="black", elinewidth=1.1, capsize=3, zorder=5,
        )
ax.set_yticks(y)
ax.set_yticklabels(sources, fontsize=8.3)
ax.set_xscale("log")
ax.set_xlabel(r"Estimated fractional frequency shift  $\Delta f / f$", fontsize=11)
ax.set_title(
    "Estimated Maser Frequency Shift from Representative Magnetic Disturbances\n"
    r"($\Delta f/f = S_H \times \Delta B$, using datasheet $S_H$ coefficients)",
    fontsize=11, pad=14,
)
ax.axvline(1e-15, color="dimgray", linestyle="--", linewidth=1)
ax.text(1e-15 * 1.15, len(sources) - 1.05, "maser noise\nfloor ~1e-15", fontsize=7.5, color="dimgray", va="top",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.75))
ax.legend(fontsize=8, loc="lower right")
ax.grid(True, which="both", axis="x", alpha=0.3)
fig.text(0.5, 0.005, HVAC_SOURCE_NOTE, ha="center", va="bottom", fontsize=7.3, color="black")
fig.tight_layout(rect=(0, 0.035, 1, 1))
fig.savefig("/home/user/workspace/maser_analysis/fig2_disturbance_impact.png", dpi=200)
print("Saved fig2_disturbance_impact.png")

# Print a small table to stdout for the report (dual units: Gauss and Tesla)
print(f"{'Disturbance source':45s}{'ΔB (G)':>10s}{'ΔB (T)':>12s}" + "".join(f"{m.splitlines()[0]:>22s}" for m in masers))
for i, s in enumerate(sources):
    label = s.splitlines()[0]
    dB_G = disturbances_G[s]
    dB_T = dB_G * 1e-4
    print(f"{label:45s}{dB_G:10.2e}{dB_T:12.2e}" + "".join(f"{data[i,j]:22.2e}" for j in range(len(masers))))

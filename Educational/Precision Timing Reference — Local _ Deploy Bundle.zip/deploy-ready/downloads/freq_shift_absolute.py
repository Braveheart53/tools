"""
Estimated ABSOLUTE frequency shift (Hz) of the hydrogen hyperfine transition
(f0 = 1,420,405,751.768 Hz) from representative magnetic-field disturbances,
computed as:

    Delta_f_Hz = (Delta_f / f) * f_carrier

using the same fractional-sensitivity coefficients (S_H, in 1/G) and the same
disturbance magnitudes (Delta_B, in G) as fig2_disturbance_impact.py.

Because the electronics package phase-locks the 5/10/100 MHz and 1 PPS
outputs to the physics package's 1.42 GHz maser transition (see corrected
fig1_physics_package.png), the FRACTIONAL shift Delta_f/f is identical at
every locked output -- it is a property of the physics package, not of any
particular output frequency. What changes with output frequency is only the
ABSOLUTE (Hz) shift, since Delta_f_Hz scales linearly with carrier frequency.
This script plots Delta_f_Hz referenced to the 1.42 GHz maser transition
(the physically perturbed quantity) and annotates the equivalent absolute
shift at the locked 10 MHz output for practical comparison.

Python 3.12
Author: Perplexity Computer / Timing project
Sources: see reference table in accompanying report.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from hvac_source import build_hvac_entries, HVAC_SOURCE_NOTE

F_MASER_HZ = 1_420_405_751.768   # H hyperfine transition, NRAO/Microsemi Rev J UG
F_10MHZ_HZ = 10_000_000.0        # locked 10 MHz output, for comparison annotation

# Same sensitivity coefficients as fig2 (fractional shift per Gauss of
# *external* ambient field, already including internal shielding factor).
sensitivity = {
    "Microchip MHM/MSM-2010\n(<3e-14/G = <3e-10/T, Rev J UG)": 3.0e-14,
    "Safran iMaser 3000\nStandard (<5e-14/G = <5e-10/T)": 5.0e-14,
    "Safran iMaser 3000\nMS option (<1e-14/G = <1e-10/T)": 1.0e-14,
}

# Same disturbance magnitudes as fig2 (Gauss), including the HVAC entries at
# every requested line-of-sight distance (see hvac_source.py for sourcing).
hvac_entries_G, hvac_brackets_G, hvac_labels_by_distance = build_hvac_entries()
HVAC_KEYS = list(hvac_labels_by_distance.values())  # ordered far -> near (25, 10, 3, 1 m)

disturbances_G = {
    **hvac_entries_G,
    "Quiet geomagnetic diurnal\nvariation (0.0002-0.0005 G\n= 20-50 nT)": 3.5e-4,
    "Moderate geomagnetic\nstorm, G2 (0.0005-0.001 G\n= 50-100 nT)": 7.5e-4,
    "Extreme geomagnetic\nstorm, G5 (>0.0025 G\n= >250 nT)": 3.0e-3,
    "Stationary-site ambient\n(elevators/motors, 0.01-0.02 G\n= 1-2 uT)": 1.5e-2,
    "Nearby moving mass\n(vehicle, dish drive, ~1 G\n= 100 uT = 1e-4 T)": 1.0,
    "Unshielded local transient\nevent (0.01 G = 1 uT = 1000 nT)\n[Kashima VLBI 1984]": 1.0e-2,
}

sources = list(disturbances_G.keys())
masers = list(sensitivity.keys())

# Delta_f/f, then absolute Delta_f (Hz) referenced to the 1.42 GHz transition
frac = np.zeros((len(sources), len(masers)))
abs_hz = np.zeros((len(sources), len(masers)))
for i, s in enumerate(sources):
    for j, m in enumerate(masers):
        frac[i, j] = disturbances_G[s] * sensitivity[m]
        abs_hz[i, j] = frac[i, j] * F_MASER_HZ

# Convert to microHz for readable axis values
abs_uhz = abs_hz * 1e6

fig, ax = plt.subplots(figsize=(11, 10.5))
y = np.arange(len(sources))
bar_h = 0.25
colors = ["#2b6cb0", "#dd6b20", "#38a169"]

for j, m in enumerate(masers):
    ax.barh(y + (j - 1) * bar_h, abs_uhz[:, j], height=bar_h, label=m, color=colors[j])

# HVAC max/min/mean error bars, same brackets as fig2, converted to abs uHz
for hvac_key in HVAC_KEYS:
    hvac_i = sources.index(hvac_key)
    bracket = hvac_brackets_G[hvac_key]
    for j, m in enumerate(masers):
        mean_v = bracket["mean"] * sensitivity[m] * F_MASER_HZ * 1e6
        lo_v = bracket["min"] * sensitivity[m] * F_MASER_HZ * 1e6
        hi_v = bracket["max"] * sensitivity[m] * F_MASER_HZ * 1e6
        ax.errorbar(
            mean_v, hvac_i + (j - 1) * bar_h,
            xerr=[[mean_v - lo_v], [hi_v - mean_v]],
            fmt="none", ecolor="black", elinewidth=1.1, capsize=3, zorder=5,
        )
ax.set_yticks(y)
ax.set_yticklabels(sources, fontsize=8.3)
ax.set_xscale("log")
ax.set_xlabel(
    r"Estimated absolute frequency shift  $\Delta f_{\rm Hz} = (\Delta f/f)\times f_{\rm carrier}$   "
    r"($\mu$Hz, referenced to $f_0$ = 1,420,405,751.768 Hz)",
    fontsize=10,
)
ax.set_title(
    "Estimated Absolute Frequency Shift from Representative Magnetic Disturbances\n"
    r"(referenced to the 1.42 GHz H hyperfine transition; fractional $\Delta f/f$ is"
    " identical at every PLL-locked output)",
    fontsize=10.5, pad=14,
)

# Maser noise floor at 1.42 GHz: (Delta_f/f)=1e-15 -> Delta_f = 1.42e-6 Hz = 1.42 uHz
noise_floor_uhz = 1e-15 * F_MASER_HZ * 1e6
ax.axvline(noise_floor_uhz, color="dimgray", linestyle="--", linewidth=1)
ax.text(noise_floor_uhz * 1.15, len(sources) - 1.05,
        f"maser noise floor\n~1e-15 -> {noise_floor_uhz:.2f} uHz\n@ 1.42 GHz",
        fontsize=7.2, color="dimgray", va="top",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.75))

ax.legend(fontsize=8, loc="lower right")
ax.grid(True, which="both", axis="x", alpha=0.3)
fig.text(0.5, 0.005, HVAC_SOURCE_NOTE, ha="center", va="bottom", fontsize=7.3, color="black")
fig.tight_layout(rect=(0, 0.035, 1, 1))
fig.savefig("/home/user/workspace/maser_analysis/fig4_freq_shift_absolute.png", dpi=200)
print("Saved fig4_freq_shift_absolute.png")

# ---------------------------------------------------------------------------
# Stdout table: absolute shift at BOTH the 1.42 GHz carrier and the locked
# 10 MHz output, to make the carrier-frequency-scaling explicit.
# ---------------------------------------------------------------------------
scale_10mhz = F_10MHZ_HZ / F_MASER_HZ  # ratio applied to Delta_f_Hz to get 10 MHz-referenced shift
print(f"Ratio f(10 MHz)/f(1.42 GHz) = {scale_10mhz:.6e}  "
      f"(absolute shift at 10 MHz output is this fraction of the 1.42 GHz shift)")
print()
header = f"{'Disturbance source':45s}{'dB (G)':>10s}" + \
    "".join(f"{m.splitlines()[0]+' @1.42GHz(uHz)':>28s}{m.splitlines()[0]+' @10MHz(uHz)':>26s}" for m in masers)
print(header)
for i, s in enumerate(sources):
    label = s.splitlines()[0]
    row = f"{label:45s}{disturbances_G[s]:10.2e}"
    for j in range(len(masers)):
        row += f"{abs_uhz[i,j]:28.3e}{abs_uhz[i,j]*scale_10mhz:26.3e}"
    print(row)

"""
Convert the estimated fractional-frequency shifts (Delta_f/f) from magnetic
disturbances into an EQUIVALENT 1PPS TIMING DRIFT RATE (SLOPE) relative to a
GPS reference, and benchmark that slope against GPS's own timing/frequency
noise floor.

Physics: for a clock with a sustained fractional-frequency offset y = Delta_f/f
relative to a (much more stable) reference, the accumulated time error grows
LINEARLY with elapsed time:

    x(tau) = y * tau        (standard clock time-deviation relation)

So a sustained field-induced y shows up as a constant SLOPE in a "maser 1PPS
minus GPS 1PPS" time-difference plot, in ns/day (or any other rate unit).
Conversion factor: 1 ns/day corresponds to y = 1e-9 / 86400 s = 1.157e-14
[U.S. Time & Frequency Bulletin No. 391, USNO/NIST].

A brief TRANSIENT disturbance (field returns to baseline after some exposure
duration tau_exp) instead leaves a permanent time-domain OFFSET (step), not a
growing slope, of magnitude:

    Delta_t_offset = y * tau_exp

Python 3.12
Author: Perplexity Computer / Timing project
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from hvac_source import build_hvac_entries, HVAC_SOURCE_NOTE

SEC_PER_DAY = 86400.0
NS_PER_DAY_TO_Y = 1e-9 / SEC_PER_DAY   # 1.157e-14, per USNO/NIST T&F Bulletin 391

sensitivity = {
    "Microchip MHM/MSM-2010\n(<3e-14/G = <3e-10/T, Rev J UG)": 3.0e-14,
    "Safran iMaser 3000\nStandard (<5e-14/G = <5e-10/T)": 5.0e-14,
    "Safran iMaser 3000\nMS option (<1e-14/G = <1e-10/T)": 1.0e-14,
}

hvac_entries_G, hvac_brackets_G, hvac_labels_by_distance = build_hvac_entries()
HVAC_KEYS = list(hvac_labels_by_distance.values())  # ordered far -> near (25, 10, 3, 1 m)

disturbances_G = {
    **hvac_entries_G,
    "Quiet geomagnetic diurnal\nvariation (0.0002-0.0005 G\n= 20-50 nT)": 3.5e-4,
    "Moderate geomagnetic\nstorm, G2 (0.0005-0.001 G\n= 50-100 nT)": 7.5e-4,
    "Extreme geomagnetic\nstorm, G5 (>0.0025 G\n= >250 nT)": 3.0e-3,
    "Stationary-site ambient\n(elevators/motors, 0.01-0.02 G\n= 1-2 uT)": 1.5e-2,
    "Nearby moving mass\n(vehicle, dish drive, ~1 G\n= 100 uT = 1e-4 T)": 1.0,
    "Unshielded local transient\nevent (0.01 G = 1 uT = 1000 nT)\n[Kashima VLBI 1984]": 1.0e-2,
}

sources = list(disturbances_G.keys())
masers = list(sensitivity.keys())

frac = np.zeros((len(sources), len(masers)))       # Delta_f/f
slope_ns_day = np.zeros((len(sources), len(masers)))  # equivalent ns/day vs GPS
for i, s in enumerate(sources):
    for j, m in enumerate(masers):
        frac[i, j] = disturbances_G[s] * sensitivity[m]
        slope_ns_day[i, j] = frac[i, j] / NS_PER_DAY_TO_Y

fig, ax = plt.subplots(figsize=(11.5, 11.0))
y = np.arange(len(sources))
bar_h = 0.25
colors = ["#2b6cb0", "#dd6b20", "#38a169"]

for j, m in enumerate(masers):
    ax.barh(y + (j - 1) * bar_h, slope_ns_day[:, j], height=bar_h, label=m, color=colors[j])

# HVAC max/min/mean error bars (same brackets, converted to ns/day)
for hvac_key in HVAC_KEYS:
    hvac_i = sources.index(hvac_key)
    bracket = hvac_brackets_G[hvac_key]
    for j, m in enumerate(masers):
        mean_v = bracket["mean"] * sensitivity[m] / NS_PER_DAY_TO_Y
        lo_v = bracket["min"] * sensitivity[m] / NS_PER_DAY_TO_Y
        hi_v = bracket["max"] * sensitivity[m] / NS_PER_DAY_TO_Y
        ax.errorbar(
            mean_v, hvac_i + (j - 1) * bar_h,
            xerr=[[mean_v - lo_v], [hi_v - mean_v]],
            fmt="none", ecolor="black", elinewidth=1.1, capsize=3, zorder=5,
        )

# --- GPS reference noise-floor bands -----------------------------------
# GPSDO own 1-day frequency stability (Allan deviation): 6e-14 to 8e-13
# [NIST TN 2297] -> converted to an equivalent ns/day slope.
gpsdo_lo = 6e-14 / NS_PER_DAY_TO_Y
gpsdo_hi = 8e-13 / NS_PER_DAY_TO_Y
ax.axvspan(gpsdo_lo, gpsdo_hi, color="#805ad5", alpha=0.12, zorder=0)
ax.axvline(gpsdo_lo, color="#805ad5", linestyle=":", linewidth=1)
ax.axvline(gpsdo_hi, color="#805ad5", linestyle=":", linewidth=1)

# GPS common-view time-transfer comparison precision: ~1-10 ns/day (1-day avg)
# [NIST Common-View GNSS Time Transfer]
ax.axvspan(1.0, 10.0, color="#e53e3e", alpha=0.10, zorder=0)

ax.set_yticks(y)
ax.set_yticklabels(sources, fontsize=8.3)
ax.set_xscale("log")
ax.set_xlabel(
    "Equivalent 1PPS timing drift (slope) vs. an ideal GPS reference, ns/day\n"
    r"(from $x(\tau) = y \times \tau$, $y=\Delta f/f$; 1 ns/day $\equiv$ 1.157e-14 fractional frequency)",
    fontsize=10,
)
ax.set_title(
    "Equivalent Maser 1PPS Timing Drift vs. GPS, from Magnetic Disturbances\n"
    "(assumes disturbance persists; shaded bands = GPS/GPSDO's own noise floor)",
    fontsize=11, pad=14,
)
ax.text(0.985, 0.985, "purple band: typical GPSDO\nown 1-day stability (~5-70 ns/day)\n"
                      "[NIST TN 2297]",
        transform=ax.transAxes, ha="right", va="top", fontsize=7.2, color="#805ad5",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#805ad5", alpha=0.85))
ax.text(0.985, 0.80, "red band: GPS common-view\ncomparison precision (~1-10 ns/day,\n1-day averaged) [NIST]",
        transform=ax.transAxes, ha="right", va="top", fontsize=7.2, color="#c53030",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#c53030", alpha=0.85))

ax.legend(fontsize=8, loc="lower right", bbox_to_anchor=(0.72, 0.02))
ax.grid(True, which="both", axis="x", alpha=0.3)
fig.text(0.5, 0.014, HVAC_SOURCE_NOTE, ha="center", va="bottom", fontsize=7.0, color="black")
fig.text(0.5, 0.002,
          "Transient events (e.g. Kashima 1984) instead leave a fixed time OFFSET = y x exposure duration, "
          "not a growing slope (see report text).",
          ha="center", va="bottom", fontsize=7.0, color="black")
fig.tight_layout(rect=(0, 0.06, 1, 1))
fig.savefig("/home/user/workspace/maser_analysis/fig5_gps_timing_drift.png", dpi=200)
print("Saved fig5_gps_timing_drift.png")

# ---------------------------------------------------------------------------
# Stdout table
# ---------------------------------------------------------------------------
print()
print(f"{'Disturbance source':45s}{'dB (G)':>10s}" +
      "".join(f"{m.splitlines()[0]+' (ns/day)':>28s}" for m in masers))
for i, s in enumerate(sources):
    label = s.splitlines()[0]
    row = f"{label:45s}{disturbances_G[s]:10.2e}"
    for j in range(len(masers)):
        row += f"{slope_ns_day[i,j]:28.3e}"
    print(row)

# ---------------------------------------------------------------------------
# Illustrative "offset" table for a transient exposure, at representative
# exposure durations (since actual field-event duration is not specified in
# the cited sources; user should substitute the real observed duration).
# ---------------------------------------------------------------------------
print()
print("Illustrative time OFFSET (ns) for a transient disturbance of duration tau,")
print("computed as Delta_t = y * tau, using the MHM/MSM-2010 (most sensitive-shielded) coefficient:")
durations = {"1 s": 1, "1 min": 60, "1 hour": 3600, "1 day": 86400}
m0 = masers[0]
for i, s in enumerate(sources):
    label = s.splitlines()[0]
    print(f"  {label}: y={frac[i,0]:.3e}")
    for dname, dsec in durations.items():
        offset_ns = frac[i, 0] * dsec * 1e9
        print(f"      tau={dname:6s}: Delta_t = {offset_ns:.3e} ns")

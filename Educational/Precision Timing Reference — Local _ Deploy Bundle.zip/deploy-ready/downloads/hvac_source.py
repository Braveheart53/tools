"""
Shared HVAC (VFD + motors, max load) magnetic-disturbance model, used by
disturbance_impact.py (fig2), freq_shift_absolute.py (fig4), and
freq_shift_vs_gps.py (fig5) so all three plots stay numerically consistent.

Methodology: near-field measurements from reputable sources are extrapolated
to the specified line-of-sight (LOS) distance using both a 1/r^2 (line-source,
near-field) and 1/r^3 (point-source, dipole far-field) falloff model
[NYC DEP EMF methodology], bracketing the two most-cited reputable
Karady et al. (IEEE Trans. Power Delivery, 1994) data points for 1-150 hp
VFD-driven motor drives:
    - 200 mG measured at 0.15 m
    - 100 mG measured at 0.60 m
giving 4 extrapolated values per distance; max/min/mean of that 4-value
bracket is reported and carried through as an explicit error bar in every
downstream chart. Cross-checked (order-of-magnitude) against BPA Draft EIS
App. E (up to 270 mG at 0.3 m) and NIOSH/CDC HHE 2009-0154-3101 (up to 300 mG
near a motor/fan).

Python 3.12
"""
from __future__ import annotations

# (r0 in meters, B0 in mG, falloff exponent n)
_COMBOS = [(0.15, 200.0, 2), (0.15, 200.0, 3), (0.60, 100.0, 2), (0.60, 100.0, 3)]

# Distances requested for the comparison sweep (meters)
HVAC_DISTANCES_M = [1, 3, 10, 25]


def bracket_mG(r_m: float) -> dict:
    """Return {'max','mean','min'} extrapolated field at distance r_m, in mG."""
    vals = [B0 * (r0 / r_m) ** n for r0, B0, n in _COMBOS]
    return {"max": max(vals), "mean": sum(vals) / len(vals), "min": min(vals)}


def hvac_label(r_m: float) -> str:
    return f"Industrial HVAC, VFD+motors,\nmax load, {r_m:g} m LOS\n(extrapolated, see note)"


def build_hvac_entries():
    """
    Returns:
        disturbances_G_entries: dict[label] = mean field in Gauss (for the
            main bar value, consistent with all other disturbance sources)
        brackets_G: dict[label] = {'max','mean','min'} in Gauss (for error bars)
        labels_by_distance: dict[r_m] = label (ordered by distance, far->near,
            matching the convention that closer sources are more severe)
    """
    disturbances_G_entries = {}
    brackets_G = {}
    labels_by_distance = {}
    for r_m in sorted(HVAC_DISTANCES_M, reverse=True):
        label = hvac_label(r_m)
        b_mG = bracket_mG(r_m)
        b_G = {k: v * 1e-3 for k, v in b_mG.items()}
        disturbances_G_entries[label] = b_G["mean"]
        brackets_G[label] = b_G
        labels_by_distance[r_m] = label
    return disturbances_G_entries, brackets_G, labels_by_distance


HVAC_SOURCE_NOTE = (
    "HVAC error bars = max/min/mean bracket from disparate reputable sources "
    "(Karady et al., IEEE Trans. Power Delivery 1994; BPA Draft EIS App. E; NIOSH/CDC HHE 2009-0154-3101),\n"
    "extrapolated to each line-of-sight distance using 1/r^2 and 1/r^3 falloff models (NYC DEP EMF methodology)."
)

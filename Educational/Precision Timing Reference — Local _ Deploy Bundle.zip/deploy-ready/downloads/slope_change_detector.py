"""
Slope-Change (Frequency-Jump) Detector for Maser-vs-GPS Timing Comparisons
============================================================================
Automatically flags abrupt step-like changes in the *slope* of a maser-minus-
GPS phase/time-difference series (i.e., discrete frequency-offset changes,
classically termed "F-steps"), using two independent, literature-grounded
statistical tests that must be run together for an event to be called
high-confidence:

  1. Sliding-window slope-break t-test (equality of two regression slopes),
     following the classical structural-break test of Chow (1960) and the
     "F-step" detection framework of Allan et al. (NBS, 1973).
  2. CUSUM (cumulative sum) detector of Page (1954) applied to the
     differentiated (frequency) series -- a slope change in phase is
     equivalent to a mean/level shift in frequency, which CUSUM is
     specifically designed to catch.

An event is reported HIGH CONFIDENCE if both tests agree within
`min_separation_days`, and CANDIDATE if only the t-test fires.

Each flagged event is automatically classified against the same GPS/GPSDO
noise-floor bands used in fig5/fig6 of the prior analysis (red band ~1-10
ns/day GPS common-view precision; purple band ~5-70 ns/day typical GPSDO
1-day ADEV), so you can see at a glance whether a detected step is even
resolvable against the reference or well above the metrology noise floor.

If an environmental log (temperature / pressure / B-field vs time) is
supplied via --env, the nearest bracketing readings for each flagged event
are printed to support the NIST TN2592 / JPL-style cross-correlation
diagnostic described previously (match slope-change timestamps against
HVAC, weather, and magnetic-disturbance telemetry).

References (IEEE format)
-------------------------
[1] E. S. Page, "Continuous Inspection Schemes," Biometrika, vol. 41,
    no. 1/2, pp. 100-115, 1954.
[2] G. C. Chow, "Tests of Equality Between Sets of Coefficients in Two
    Linear Regressions," Econometrica, vol. 28, no. 3, pp. 591-605, 1960.
[3] D. W. Allan, D. J. Glaze, H. E. Machlan, A. E. Wainwright,
    H. Hellwig, J. A. Barnes, and J. E. Gray, "Performance, Modeling, and
    Simulation of Some Cesium Beam Clocks," in Proc. 27th Annu. Symp.
    Frequency Control, NBS, 1973. [Online].
    Available: https://tf.nist.gov/general/pdf/53.pdf
[4] L. Galleani and P. Tavella, "Robust Detection of Fast and Slow
    Frequency Jumps of Atomic Clocks," IEEE Trans. Ultrason. Ferroelectr.
    Freq. Control, vol. 64, no. 2, pp. 475-485, Feb. 2017,
    doi: 10.1109/TUFFC.2016.2625311.
[5] C. Truong, L. Oudre, and N. Vayatis, "Selective Review of Offline
    Change Point Detection Methods," Signal Processing, vol. 167,
    p. 107299, 2020.
[6] R. Killick, P. Fearnhead, and I. A. Eckley, "Optimal Detection of
    Changepoints With a Linear Computational Cost," J. Amer. Statist.
    Assoc., vol. 107, no. 500, pp. 1590-1598, 2012.

Usage
-----
    python3.12 slope_change_detector.py --data mytimediffs.csv --env myenv.csv
    python3.12 slope_change_detector.py            # runs on synthetic demo data

Input CSV format (--data): columns t_days, delta_ns
Input CSV format (--env, optional): columns t_days, and any of
    temp_C, pressure_inHg, b_field_mG

Python 3.12
"""

from __future__ import annotations
import argparse
import csv
from dataclasses import dataclass, field

import numpy as np
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

NS_PER_DAY_TO_Y = 1.157e-14  # fractional-frequency equivalent of 1 ns/day slope

# GPS/GPSDO noise-floor bands, ns/day (same convention as fig5/fig6)
GPS_COMMON_VIEW_BAND = (1.0, 10.0)   # red band: GPS common-view comparison precision
GPSDO_ADEV_BAND = (5.0, 70.0)        # purple band: typical GPSDO 1-day stability


@dataclass
class SlopeChangeEvent:
    index: int
    t_days: float
    slope_before_ns_day: float
    slope_after_ns_day: float
    delta_slope_ns_day: float
    t_stat: float
    p_value: float
    cusum_flag: bool
    classification: str
    env_context: dict = field(default_factory=dict)


# --------------------------------------------------------------------------
# Data loading
# --------------------------------------------------------------------------

def load_series(csv_path):
    t, x = [], []
    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t.append(float(row["t_days"]))
            x.append(float(row["delta_ns"]))
    order = np.argsort(t)
    return np.array(t)[order], np.array(x)[order]


def synthetic_demo_series(seed=42):
    """Illustrative demo series with 3 KNOWN injected slope-change events,
    used only to validate/demonstrate detector behavior. NOT real measured
    data -- replace with --data for an actual analysis."""
    rng = np.random.default_rng(seed)
    t = np.linspace(0, 60, 60 * 24)  # 60 days, hourly samples
    slopes = np.piecewise(
        t,
        [t < 15, (t >= 15) & (t < 35), (t >= 35) & (t < 48), t >= 48],
        [0.5, 3.2, 0.8, 6.0],  # ns/day segments
    )
    x = np.cumsum(slopes * np.gradient(t))
    x += rng.normal(0, 0.6, size=t.size)  # ~0.6 ns white noise, typical TIC precision
    return t, x, [15.0, 35.0, 48.0]


def load_environment_log(csv_path):
    rows = []
    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append({k: float(v) for k, v in row.items() if v not in (None, "")})
    return rows


def nearest_env_reading(env_rows, t_query, field="t_days"):
    if not env_rows:
        return {}
    idx = min(range(len(env_rows)), key=lambda i: abs(env_rows[i][field] - t_query))
    return env_rows[idx]


# --------------------------------------------------------------------------
# Method 1: sliding-window slope-break t-test (Chow-style)
# --------------------------------------------------------------------------

def _linfit(t_seg, x_seg):
    A = np.vstack([t_seg, np.ones_like(t_seg)]).T
    coef, _, _, _ = np.linalg.lstsq(A, x_seg, rcond=None)
    slope, intercept = coef
    resid = x_seg - (slope * t_seg + intercept)
    rss = float(np.sum(resid ** 2))
    return slope, intercept, rss


def slope_break_tscan(t, x, window_days, min_points=6):
    """Evaluate a two-slope comparison t-test at every sample, using a
    trailing window and a leading window of width `window_days` each.
    Returns t_stat, p_value, slope_before, slope_after arrays (NaN where
    not enough points exist on either side)."""
    n = len(t)
    t_stat = np.full(n, np.nan)
    p_val = np.full(n, np.nan)
    slope_b = np.full(n, np.nan)
    slope_a = np.full(n, np.nan)

    for i in range(n):
        # require a FULL window on both sides to avoid boundary/edge artifacts
        if (t[i] - t[0]) < window_days or (t[-1] - t[i]) < window_days:
            continue
        left = (t >= t[i] - window_days) & (t <= t[i])
        right = (t >= t[i]) & (t <= t[i] + window_days)
        if left.sum() < min_points or right.sum() < min_points:
            continue
        tl, xl = t[left], x[left]
        tr, xr = t[right], x[right]
        b1, _, rss1 = _linfit(tl, xl)
        b2, _, rss2 = _linfit(tr, xr)
        n1, n2 = len(tl), len(tr)
        dof = n1 + n2 - 4
        if dof <= 0:
            continue
        pooled_var = (rss1 + rss2) / dof
        sxx1 = np.sum((tl - tl.mean()) ** 2)
        sxx2 = np.sum((tr - tr.mean()) ** 2)
        if sxx1 <= 0 or sxx2 <= 0:
            continue
        se = np.sqrt(pooled_var * (1.0 / sxx1 + 1.0 / sxx2))
        if se <= 0:
            continue
        tstat = (b2 - b1) / se
        p = 2 * (1 - stats.t.cdf(abs(tstat), df=dof))
        t_stat[i], p_val[i], slope_b[i], slope_a[i] = tstat, p, b1, b2
    return t_stat, p_val, slope_b, slope_a


# --------------------------------------------------------------------------
# Method 2: CUSUM on the differentiated (frequency) series (Page, 1954)
# --------------------------------------------------------------------------

def cusum_on_slope_series(slope_series, k_sigma=1.0, h_sigma=4.0, reest_window=15):
    """Adaptive two-sided CUSUM (Page, 1954) applied to the *smoothed rolling-
    window slope estimate* (not the raw point-to-point derivative, which is
    dominated by time-interval-counter noise once differentiated -- a well
    known pitfall in clock-comparison analysis). After each detected shift,
    the CUSUM reference level is re-estimated from the following segment,
    the standard control-chart practice for tracking a series through
    multiple level (here: frequency) changes."""
    n = len(slope_series)
    flags = np.zeros(n, dtype=bool)
    valid = ~np.isnan(slope_series)
    if valid.sum() < 2 * reest_window:
        return flags
    idxs = np.where(valid)[0]
    y = slope_series[valid]
    sigma = np.std(y)
    if sigma == 0:
        return flags
    k, h = k_sigma * sigma, h_sigma * sigma
    mu = np.mean(y[:reest_window])
    sh = sl = 0.0
    j = reest_window
    while j < len(y):
        sh = max(0.0, sh + (y[j] - mu) - k)
        sl = min(0.0, sl + (y[j] - mu) + k)
        if sh > h or sl < -h:
            flags[idxs[j]] = True
            sh = sl = 0.0
            mu = np.mean(y[j:j + reest_window]) if j + reest_window <= len(y) else np.mean(y[j:])
        j += 1
    return flags


# --------------------------------------------------------------------------
# Classification against GPS/GPSDO noise floor
# --------------------------------------------------------------------------

def classify_step(delta_slope_ns_day):
    d = abs(delta_slope_ns_day)
    lo_r, hi_r = GPS_COMMON_VIEW_BAND
    _, hi_p = GPSDO_ADEV_BAND
    if d < lo_r:
        return "Below GPS common-view noise floor -- likely not resolvable"
    elif d <= hi_r:
        return "Marginal -- within GPS common-view precision band"
    elif d <= hi_p:
        return "Significant -- within/above typical GPSDO 1-day stability"
    else:
        return "Large -- well above typical GPSDO 1-day stability"


# --------------------------------------------------------------------------
# Event detection: combine both methods
# --------------------------------------------------------------------------

def detect_events(t, x, window_days=5.0, min_points=6, p_threshold=0.01,
                   min_separation_days=2.0, env_rows=None):
    t_stat, p_val, slope_b, slope_a = slope_break_tscan(t, x, window_days, min_points)
    # Use the leading-window rolling slope estimate as the smoothed "frequency"
    # series fed to CUSUM -- far less noisy than a raw point-to-point derivative.
    cusum_flags = cusum_on_slope_series(slope_a)
    cusum_times = t[cusum_flags]

    valid = ~np.isnan(p_val)
    candidates = []
    for i in np.where(valid & (p_val < p_threshold))[0]:
        lo, hi = max(0, i - 3), min(len(t), i + 4)
        window_vals = np.nan_to_num(np.abs(t_stat[lo:hi]), nan=0.0)
        if np.argmax(window_vals) == (i - lo):
            candidates.append(i)

    candidates.sort(key=lambda i: -abs(t_stat[i]))
    accepted = []
    for i in candidates:
        if all(abs(t[i] - t[j]) >= min_separation_days for j in accepted):
            accepted.append(i)
    accepted.sort()

    events = []
    for i in accepted:
        delta_slope = slope_a[i] - slope_b[i]
        # Because slope_a is a FORWARD rolling-window slope, a real level shift
        # smears out over ~window_days as the CUSUM window slides across it, so
        # corroboration is checked within one window width in time, not samples.
        cusum_nearby = bool(len(cusum_times) and np.min(np.abs(cusum_times - t[i])) <= window_days)
        ev = SlopeChangeEvent(
            index=int(i), t_days=float(t[i]),
            slope_before_ns_day=float(slope_b[i]), slope_after_ns_day=float(slope_a[i]),
            delta_slope_ns_day=float(delta_slope), t_stat=float(t_stat[i]),
            p_value=float(p_val[i]), cusum_flag=cusum_nearby,
            classification=classify_step(delta_slope),
        )
        if env_rows:
            ev.env_context = nearest_env_reading(env_rows, ev.t_days)
        events.append(ev)
    return events, t_stat, p_val


# --------------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------------

def print_report(events):
    print(f"\n{'='*104}")
    print(f"{'Time(d)':>8} {'Before':>9} {'After':>9} {'D-slope':>9} {'t-stat':>8} "
          f"{'p-value':>10} {'CUSUM':>6} {'Confid.':>10}  Classification")
    print(f"{'':>8} {'ns/day':>9} {'ns/day':>9} {'ns/day':>9}")
    print("-" * 104)
    for ev in events:
        conf = "HIGH" if ev.cusum_flag else "candidate"
        print(f"{ev.t_days:8.2f} {ev.slope_before_ns_day:9.3f} {ev.slope_after_ns_day:9.3f} "
              f"{ev.delta_slope_ns_day:9.3f} {ev.t_stat:8.2f} {ev.p_value:10.2e} "
              f"{'yes' if ev.cusum_flag else 'no':>6} {conf:>10}  {ev.classification}")
        if ev.env_context:
            extras = ", ".join(f"{k}={v:.3g}" for k, v in ev.env_context.items() if k != "t_days")
            print(f"           env @ nearest sample: {extras}")
    print("=" * 104)


def plot_events(t, x, events, out_path, title_suffix=""):
    fig, ax = plt.subplots(figsize=(11.5, 6.5))
    ax.plot(t, x, color="#2b6cb0", lw=1.0, label="Maser - GPS time difference")

    ymin, ymax = ax.get_ylim()
    for ev in events:
        color = "#c53030" if ev.cusum_flag else "#dd6b20"
        ax.axvline(ev.t_days, color=color, ls="--", lw=1.3, alpha=0.85, zorder=4)
        ax.annotate(
            f"{ev.delta_slope_ns_day:+.2f} ns/day, p={ev.p_value:.1e}",
            xy=(ev.t_days, ymax), xycoords="data",
            xytext=(4, -4), textcoords="offset points",
            fontsize=7.0, color=color, rotation=90, va="top", ha="left",
        )

    ax.set_xlabel("Time (days)")
    ax.set_ylabel("Time difference, maser - GPS (ns)")
    ax.set_title("Automated Slope-Change Detection" + title_suffix)
    ax.grid(True, alpha=0.3)

    legend_elems = [
        Line2D([0], [0], color="#2b6cb0", lw=1.5, label="Time-difference series"),
        Line2D([0], [0], color="#c53030", ls="--", lw=1.3, label="High confidence (t-test + CUSUM agree)"),
        Line2D([0], [0], color="#dd6b20", ls="--", lw=1.3, label="Candidate (t-test only)"),
    ]
    ax.legend(handles=legend_elems, loc="upper left", fontsize=8)

    fig.text(0.5, 0.02,
              "Methods: sliding-window slope-break t-test (Chow, 1960) + CUSUM on differentiated series (Page, 1954);\n"
              "see Allan et al. 1973 (NIST, tf.nist.gov/general/pdf/53.pdf) and Galleani & Tavella,\n"
              "IEEE Trans. UFFC 64(2), 475-485, 2017 for F-step detection in atomic clock comparisons.",
              ha="center", va="bottom", fontsize=6.6, color="black")
    fig.tight_layout(rect=(0, 0.10, 1, 1))
    fig.savefig(out_path, dpi=200)
    print(f"Saved {out_path}")


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description="Detect abrupt slope (frequency-offset) changes in a maser-vs-GPS timing series.")
    ap.add_argument("--data", type=str, default=None,
                     help="CSV with columns t_days,delta_ns. Omit to run on synthetic demo data.")
    ap.add_argument("--env", type=str, default=None,
                     help="Optional CSV with columns t_days,[temp_C],[pressure_inHg],[b_field_mG].")
    ap.add_argument("--window-days", type=float, default=5.0,
                     help="Half-window width (days) for the slope-break t-test. Default 5.")
    ap.add_argument("--p-threshold", type=float, default=0.01,
                     help="p-value threshold for flagging a candidate slope break. Default 0.01.")
    ap.add_argument("--min-separation-days", type=float, default=2.0,
                     help="Minimum spacing (days) between reported events. Default 2.")
    ap.add_argument("--out", type=str,
                     default="/home/user/workspace/maser_analysis/fig7_slope_change_detection.png")
    args = ap.parse_args()

    if args.data:
        t, x = load_series(args.data)
        title_suffix = ""
    else:
        t, x, injected = synthetic_demo_series()
        title_suffix = "\n(SYNTHETIC DEMO DATA -- injected steps at t = " + \
                        ", ".join(f"{d:.0f}" for d in injected) + " days)"
        print("No --data supplied: running on a synthetic demo series with known injected")
        print(f"slope-change events at t = {injected} days, to validate detector behavior.")
        print("Use --data yourfile.csv (columns: t_days, delta_ns) for a real analysis.\n")

    env_rows = load_environment_log(args.env) if args.env else None

    events, _, _ = detect_events(
        t, x, window_days=args.window_days, p_threshold=args.p_threshold,
        min_separation_days=args.min_separation_days, env_rows=env_rows,
    )

    if not events:
        print("No slope-change events detected at the current threshold.")
    else:
        print_report(events)

    plot_events(t, x, events, args.out, title_suffix=title_suffix)


if __name__ == "__main__":
    main()

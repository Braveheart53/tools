"""
Equivalent 1PPS timing-drift SLOPE vs GPS from non-magnetic environmental
step disturbances (temperature, barometric pressure), using the ONLY
manufacturer-published sensitivity coefficients found in a reputable source
for these two effects: the NRAO-hosted Microsemi/Microchip MHM/MSM-2010
User Guide Rev J.

    Temperature sensitivity:      < 1e-14 / degC   (20-24 degC range)
    Barometric pressure sens.:    < 1e-14 / in Hg

These are "less than" (guaranteed maximum) manufacturer specs, not measured
typical values -- treated here as upper-bound estimates, same convention
used for the magnetic-sensitivity chart (fig2/fig4/fig5).

Python 3.12
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt

SEC_PER_DAY = 86400.0
NS_PER_DAY_TO_Y = 1e-9 / SEC_PER_DAY  # 1.157e-14, per USNO/NIST T&F Bulletin 391

S_T = 1.0e-14   # /degC, MHM/MSM-2010 Rev J UG, "less than" spec
S_P = 1.0e-14   # /inHg, MHM/MSM-2010 Rev J UG, "less than" spec

scenarios = {
    "HVAC thermostat cycle,\nsingle-stage (dT = 2 degC)": ("T", 2.0),
    "HVAC thermostat cycle,\nwide deadband (dT = 5 degC)": ("T", 5.0),
    "Weather front passage,\nmild (dP = 0.5 inHg)": ("P", 0.5),
    "Weather front passage,\nstrong nor'easter (dP = 1.5 inHg)": ("P", 1.5),
    "Major storm system,\nextreme (dP = 3.0 inHg)": ("P", 3.0),
}

labels = list(scenarios.keys())
frac = []
for lbl, (kind, delta) in scenarios.items():
    coeff = S_T if kind == "T" else S_P
    frac.append(coeff * delta)
frac = np.array(frac)
slope_ns_day = frac / NS_PER_DAY_TO_Y

fig, ax = plt.subplots(figsize=(11, 6.2))
y = np.arange(len(labels))
colors = ["#c05621" if scenarios[l][0] == "T" else "#2c5282" for l in labels]
ax.barh(y, slope_ns_day, color=colors, height=0.55)

# GPS reference bands, same as fig5
gpsdo_lo = 6e-14 / NS_PER_DAY_TO_Y
gpsdo_hi = 8e-13 / NS_PER_DAY_TO_Y
ax.axvspan(gpsdo_lo, gpsdo_hi, color="#805ad5", alpha=0.12, zorder=0)
ax.axvline(gpsdo_lo, color="#805ad5", linestyle=":", linewidth=1)
ax.axvline(gpsdo_hi, color="#805ad5", linestyle=":", linewidth=1)
ax.axvspan(1.0, 10.0, color="#e53e3e", alpha=0.10, zorder=0)

ax.set_yticks(y)
ax.set_yticklabels(labels, fontsize=9)
ax.set_xscale("log")
ax.set_xlabel(
    "Equivalent 1PPS timing drift (slope) vs. an ideal GPS reference, ns/day\n"
    r"(using MHM/MSM-2010 datasheet coefficients: $S_T$<1e-14/degC, $S_P$<1e-14/inHg)",
    fontsize=10,
)
ax.set_title(
    "Equivalent Maser Timing Drift vs. GPS, from Temperature & Barometric\n"
    "Pressure Step Disturbances (non-magnetic causes)",
    fontsize=11.5, pad=14,
)
from matplotlib.patches import Patch
legend_elems = [
    Patch(facecolor="#c05621", label="Temperature-induced (dT)"),
    Patch(facecolor="#2c5282", label="Pressure-induced (dP)"),
]
ax.legend(handles=legend_elems, fontsize=8.5, loc="lower right")
ax.text(0.985, 0.96, "purple band: typical GPSDO\nown 1-day stability (~5-70 ns/day)\n[NIST TN 2297]",
        transform=ax.transAxes, ha="right", va="top", fontsize=7.2, color="#805ad5",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#805ad5", alpha=0.85))
ax.text(0.985, 0.74, "red band: GPS common-view\ncomparison precision (~1-10 ns/day)\n[NIST]",
        transform=ax.transAxes, ha="right", va="top", fontsize=7.2, color="#c53030",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#c53030", alpha=0.85))
ax.grid(True, which="both", axis="x", alpha=0.3)
fig.text(0.5, 0.018,
          "Coefficients: Microsemi/Microchip MHM/MSM-2010 User Guide Rev J (NRAO-hosted), \"less than\" (max) spec.",
          ha="center", va="bottom", fontsize=7.2, color="black")
fig.text(0.5, 0.004,
          "Scenario magnitudes are illustrative, not site-specific measurements.",
          ha="center", va="bottom", fontsize=7.2, color="black")
fig.tight_layout(rect=(0, 0.065, 1, 1))
fig.savefig("/home/user/workspace/maser_analysis/fig6_thermal_pressure_slope.png", dpi=200)
print("Saved fig6_thermal_pressure_slope.png")
for lbl, s in zip(labels, slope_ns_day):
    print(f"{lbl.splitlines()[0]:50s} {s:10.3f} ns/day")

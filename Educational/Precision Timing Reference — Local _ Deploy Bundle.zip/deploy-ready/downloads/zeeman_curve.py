"""
Second-order (quadratic) Zeeman shift of the hydrogen 1420.405 MHz clock
transition (F=1, mF=0 -> F=0, mF=0), and illustration of why H-masers are
biased to operate at a small, well-controlled C-field.

Delta_nu_B = K_B * B^2 ,   K_B = 2750 Hz/Gauss^2 = 2.750e11 Hz/T^2
(Vessot, "Hydrogen Maser Frequency Standard," NASA TM 19800020315, Eq. for
Af_magnetic = 2750 H^2 (H in Gauss); cross-checked against Kleppner et al.
1962 and NIST TN-13 (~2750-2775 Hz/G^2 range in the literature).
NOTE: an earlier draft of this figure used an incorrectly-scaled
K_B = 2.773e10 Hz/T^2 (10x too small); this has been corrected here.

Python 3.12
"""
import numpy as np
import matplotlib.pyplot as plt

K_B = 2.750e11  # Hz / T^2  (= 2750 Hz/G^2, second-order Zeeman coefficient, clock transition)
h = 6.62607015e-34
mu_B = 9.2740100783e-24

# Field axis in milligauss for realistic maser operating range
B_mG = np.linspace(0, 5, 500)
B_T = B_mG * 1e-3 * 1e-4  # mG -> G -> T

dnu = K_B * B_T**2  # Hz

fig, ax1 = plt.subplots(figsize=(9, 6))
ax1.plot(B_mG, dnu, color="#2b6cb0", lw=2)
ax1.set_xlabel("Internal C-field, B (milligauss, mG)")
ax1.set_ylabel(r"Second-order Zeeman shift $\Delta\nu_B$ (Hz)", color="#2b6cb0")
ax1.tick_params(axis="y", labelcolor="#2b6cb0")
ax1.set_title(
    r"Quadratic Magnetic (Zeeman) Frequency Shift of the H Clock Transition"
    "\n" r"$\Delta\nu_B = K_B B^2$,  $K_B$ = 2750 Hz/G$^2$ = 2.750$\times10^{11}$ Hz/T$^2$"
)

# Secondary top x-axis in nanotesla (1 mG = 100 nT) for dual-unit display
def mg_to_nt(x):
    return x * 100.0  # 1 mG = 1e-3 G = 1e-7 T = 100 nT

def nt_to_mg(x):
    return x / 100.0

ax_top = ax1.secondary_xaxis("top", functions=(mg_to_nt, nt_to_mg))
ax_top.set_xlabel("Internal C-field, B (nanotesla, nT)")

# mark typical operating points, dual units (Gauss/Tesla, i.e. mG and nT)
annot_specs = [
    ("MHM/MSM-2010 C-field\n(~0.5 mG = 50 nT)", 0.5, "black", (15, 35)),
    ("iMaser 3000 typical C-field\n(~1 mG = 100 nT)", 1.0, "red", (25, -45)),
]
for label, b_mg, color, offset in annot_specs:
    b_T = b_mg * 1e-3 * 1e-4
    dv = K_B * b_T**2
    ax1.plot(b_mg, dv, "o", color=color, zorder=5)
    ax1.annotate(
        label, (b_mg, dv), textcoords="offset points", xytext=offset, fontsize=8, color=color,
        arrowprops=dict(arrowstyle="-", color=color, lw=0.8),
    )

ax1.grid(alpha=0.3)
fig.tight_layout()
fig.savefig("/home/user/workspace/maser_analysis/fig3_zeeman_curve.png", dpi=200)
print("Saved fig3_zeeman_curve.png")

# Sensitivity slope d(dnu)/dB at operating point, to show *local linearization*
# that manufacturers quote as "X per Gauss" around the bias field.
for b_mg in (0.5, 1.0):
    b_T = b_mg * 1e-3 * 1e-4
    slope_per_T = 2 * K_B * b_T  # Hz per Tesla, local slope
    slope_per_G = slope_per_T * 1e-4  # Hz per Gauss
    f0 = 1.420405751e9
    frac_per_G = slope_per_G / f0
    print(f"At C-field {b_mg} mG: local d(nu)/dB = {slope_per_G:.3e} Hz/G "
          f"=> fractional {frac_per_G:.3e} /G (before shielding)")
